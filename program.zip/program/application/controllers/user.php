<?php
defined('BASEPATH') or exit('No direct script access allowed');

class User extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if (!$this->db->get_where('regis_siswa', ['username' => $this->session->userdata('username')])->row_array()) {
            redirect('auth/blocked');
        }
    }
    public function index()
    {
        $data['title'] = 'Selamat Datang';
        $data2['regis_siswa'] = $this->db->get_where('regis_siswa', ['username' => $this
            ->session->userdata('username')])->row_array();
        $this->load->view('tamplates/user/headeruser', $data);
        $this->load->view('tamplates/user/sidebaruser', $data);
        $this->load->view('tamplates/user/topbaruser', $data2);
        $this->load->view('user/index', $data);
        $this->load->view('tamplates/user/footeruser');
    }

    public function datatkpg()
    {
        $data['title'] = 'Data Calon Siswa TK - PG BPI Bandung';
        $data2['regis_siswa'] = $this->db->get_where('regis_siswa', ['username' => $this
            ->session->userdata('username')])->row_array();
        $data['regis_siswa'] = $this->db->query("SELECT * FROM regis_siswa where sekolah='TK-PG BPI '")->result_array();
        $this->load->view('tamplates/user/headeruser', $data);
        $this->load->view('tamplates/user/sidebaruser', $data);
        $this->load->view('tamplates/user/topbaruser', $data2);
        $this->load->view('user/datatkpg', $data);
        $this->load->view('tamplates/user/footeruser');
    }
    public function datasd()
    {
        $data['title'] = 'Data Calon Siswa SD BPI Bandung';
        $data2['regis_siswa'] = $this->db->get_where('regis_siswa', ['username' => $this
            ->session->userdata('username')])->row_array();
        $data['regis_siswa'] = $this->db->query("SELECT * FROM regis_siswa where sekolah='SD BPI '")->result_array();
        $this->load->view('tamplates/user/headeruser', $data);
        $this->load->view('tamplates/user/sidebaruser', $data);
        $this->load->view('tamplates/user/topbaruser', $data2);
        $this->load->view('user/datasd', $data);
        $this->load->view('tamplates/user/footeruser');
    }
    public function datasmp()
    {
        $data['title'] = 'Data Calon Siswa SMP BPI Bandung';
        $data2['regis_siswa'] = $this->db->get_where('regis_siswa', ['username' => $this
            ->session->userdata('username')])->row_array();
        $data['regis_siswa'] = $this->db->query("SELECT * FROM regis_siswa where sekolah='SMP BPI '")->result_array();
        $this->load->view('tamplates/user/headeruser', $data);
        $this->load->view('tamplates/user/sidebaruser', $data);
        $this->load->view('tamplates/user/topbaruser', $data2);
        $this->load->view('user/datasmp', $data);
        $this->load->view('tamplates/user/footeruser');
    }
    public function datasmabpi1()
    {
        $data['title'] = 'Data Calon Siswa SMA BPI 1 Bandung';
        $data2['regis_siswa'] = $this->db->get_where('regis_siswa', ['username' => $this
            ->session->userdata('username')])->row_array();
        $data['regis_siswa'] = $this->db->query("SELECT * FROM regis_siswa where sekolah='SMA BPI 1'")->result_array();
        $this->load->view('tamplates/user/headeruser', $data);
        $this->load->view('tamplates/user/sidebaruser', $data);
        $this->load->view('tamplates/user/topbaruser', $data2);
        $this->load->view('user/datasmabpi1', $data);
        $this->load->view('tamplates/user/footeruser');
    }
    public function datasmabpi2()
    {
        $data['title'] = 'Data Calon Siswa SMA BPI 2 Bandung';
        $data2['regis_siswa'] = $this->db->get_where('regis_siswa', ['username' => $this
            ->session->userdata('username')])->row_array();
        $data['regis_siswa'] = $this->db->query("SELECT * FROM regis_siswa where sekolah='SMA BPI 2'")->result_array();
        $this->load->view('tamplates/user/headeruser', $data);
        $this->load->view('tamplates/user/sidebaruser', $data);
        $this->load->view('tamplates/user/topbaruser', $data2);
        $this->load->view('user/datasmabpi2', $data);
        $this->load->view('tamplates/user/footeruser');
    }
    public function datasmk()
    {
        $data['title'] = 'Data Calon Siswa SMK BPI Bandung';
        $data2['regis_siswa'] = $this->db->get_where('regis_siswa', ['username' => $this
            ->session->userdata('username')])->row_array();
        $data['regis_siswa'] = $this->db->query("SELECT * FROM regis_siswa where sekolah='SMK BPI'")->result_array();
        $this->load->view('tamplates/user/headeruser', $data);
        $this->load->view('tamplates/user/sidebaruser', $data);
        $this->load->view('tamplates/user/topbaruser', $data2);
        $this->load->view('user/datasmk', $data);
        $this->load->view('tamplates/user/footeruser');
    }
    public function tkbpi()
    {
        $data['title'] = 'Informasi Mengenai TK-PG BPI';
        $data2['regis_siswa'] = $this->db->get_where('regis_siswa', ['username' => $this
            ->session->userdata('username')])->row_array();
        $data['regis_siswa'] = $this->db->get('regis_siswa')->result_array();

        $this->load->view('tamplates/user/headeruser', $data);
        $this->load->view('tamplates/user/sidebaruser', $data);
        $this->load->view('tamplates/user/topbaruser', $data2);
        $this->load->view('user/tkbpi', $data);
        $this->load->view('tamplates/user/footeruser');
    }
    public function sdbpi()
    {
        $data['title'] = 'Informasi Mengenai SD BPI';
        $data2['regis_siswa'] = $this->db->get_where('regis_siswa', ['username' => $this
            ->session->userdata('username')])->row_array();
        $data['regis_siswa'] = $this->db->get('regis_siswa')->result_array();

        $this->load->view('tamplates/user/headeruser', $data);
        $this->load->view('tamplates/user/sidebaruser', $data);
        $this->load->view('tamplates/user/topbaruser', $data2);
        $this->load->view('user/sdbpi', $data);
        $this->load->view('tamplates/user/footeruser');
    }
    public function smpbpi()
    {
        $data['title'] = 'Informasi Mengenai SMP BPI';
        $data2['regis_siswa'] = $this->db->get_where('regis_siswa', ['username' => $this
            ->session->userdata('username')])->row_array();
        $data['regis_siswa'] = $this->db->get('regis_siswa')->result_array();

        $this->load->view('tamplates/user/headeruser', $data);
        $this->load->view('tamplates/user/sidebaruser', $data);
        $this->load->view('tamplates/user/topbaruser', $data2);
        $this->load->view('user/smpbpi', $data);
        $this->load->view('tamplates/user/footeruser');
    }
    public function smabpi1()
    {
        $data['title'] = 'Informasi Mengenai SMA BPI 1';
        $data2['regis_siswa'] = $this->db->get_where('regis_siswa', ['username' => $this
            ->session->userdata('username')])->row_array();
        $data['regis_siswa'] = $this->db->get('regis_siswa')->result_array();

        $this->load->view('tamplates/user/headeruser', $data);
        $this->load->view('tamplates/user/sidebaruser', $data);
        $this->load->view('tamplates/user/topbaruser', $data2);
        $this->load->view('user/smabpi1', $data);
        $this->load->view('tamplates/user/footeruser');
    }
    public function smabpi2()
    {
        $data['title'] = 'Informasi Mengenai SMA BPI 2';
        $data2['regis_siswa'] = $this->db->get_where('regis_siswa', ['username' => $this
            ->session->userdata('username')])->row_array();
        $data['regis_siswa'] = $this->db->get('regis_siswa')->result_array();

        $this->load->view('tamplates/user/headeruser', $data);
        $this->load->view('tamplates/user/sidebaruser', $data);
        $this->load->view('tamplates/user/topbaruser', $data2);
        $this->load->view('user/smabpi2', $data);
        $this->load->view('tamplates/user/footeruser');
    }
    public function smkbpi()
    {
        $data['title'] = 'Informasi Mengenai SMK BPI';
        $data2['regis_siswa'] = $this->db->get_where('regis_siswa', ['username' => $this
            ->session->userdata('username')])->row_array();
        $data['regis_siswa'] = $this->db->get('regis_siswa')->result_array();

        $this->load->view('tamplates/user/headeruser', $data);
        $this->load->view('tamplates/user/sidebaruser', $data);
        $this->load->view('tamplates/user/topbaruser', $data2);
        $this->load->view('user/smkbpi', $data);
        $this->load->view('tamplates/user/footeruser');
    }
    public function petunjuk()
    {
        $data['title'] = 'Petunjuk';
        $data2['regis_siswa'] = $this->db->get_where('regis_siswa', ['username' => $this
            ->session->userdata('username')])->row_array();
        $data['regis_siswa'] = $this->db->get('regis_siswa')->result_array();

        $this->load->view('tamplates/user/headeruser', $data);
        $this->load->view('tamplates/user/sidebaruser', $data);
        $this->load->view('tamplates/user/topbaruser', $data2);
        $this->load->view('user/petunjuk', $data);
        $this->load->view('tamplates/user/footeruser');
    }
    public function pengumuman()
    {
        $data['title'] = 'Pengumuman';
        $data2['regis_siswa'] = $this->db->get_where('regis_siswa', ['username' => $this
            ->session->userdata('username')])->row_array();
        $data['pengumuman'] = $this->db->get('pengumuman')->result_array();

        $this->load->view('tamplates/user/headeruser', $data);
        $this->load->view('tamplates/user/sidebaruser', $data);
        $this->load->view('tamplates/user/topbaruser', $data2);
        $this->load->view('user/pengumuman', $data);
        $this->load->view('tamplates/user/footeruser');
    }
}
