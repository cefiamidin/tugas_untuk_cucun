<?php
defined('BASEPATH') or exit('No direct script access allowed');

class auth extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
    }

    public function index()
    {
        $this->form_validation->set_rules('username', 'Username', 'required|trim');
        $this->form_validation->set_rules('password', 'Password', 'required|trim');

        if ($this->form_validation->run() == false) {
            $data['title'] = 'Login Admin';
            $this->load->view('tamplates/auth_header', $data);
            $this->load->view('auth/login');
            $this->load->view('tamplates/auth_footer');
        } else {
            //validasi berhasil login
            $this->_login();
        }
    }

    private function _login()
    {
        $username = $this->input->post('username');
        $password = $this->input->post('password');

        $admin = $this->db->get_where('admin', ['username' => $username])->row_array();
        $regis_siswa = $this->db->get_where('regis_siswa', ['username' => $username])->row_array();

        if ($admin . $regis_siswa) {
            // username ada
            //jika user aktif
            if (($admin['verifikasi'] == 1) . ($regis_siswa['verifikasi'] == 1)) {

                // cek password
                if (password_verify($password, $admin['password'])) {
                    $data = [
                        'username' => $admin['username'],
                        'password' => $admin['password'],
                        'role_id' => $admin['role_id']
                    ];

                    $this->session->set_userdata($data);
                    redirect('Admin');
                } elseif (password_verify($password, $regis_siswa['password'])) {
                    $data = [
                        'username' => $regis_siswa['username'],
                        'password' =>  $regis_siswa['password'],
                        'role_id' => $regis_siswa['role_id']
                    ];
                    $this->session->set_userdata($data);
                    redirect('User');
                } else {
                    $this->session->set_flashdata(
                        'message',
                        '<div class="alert alert-danger" role="alert">
                    Password Salah ! 
                    </div>'
                    );
                    redirect('auth');
                }
            } else {
                $this->session->set_flashdata(
                    'message',
                    '<div class="alert alert-danger" role="alert">
                Akun Belum Di Verifikasi
                </div>'
                );
                redirect('auth');
            }
        } else {
            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-danger" role="alert">
                Username Tidak Ada!
                </div>'
            );

            redirect('auth');
        }
    }
    public function registrasi()
    {
        // input registrasi siswa

        if ($this->form_validation->run() == false) {
            $data['title'] = 'Pendaftaran Siswa';
            $this->load->view('tamplates/auth_header', $data);
            $this->load->view('auth/registrasi');
            $this->load->view('tamplates/auth_footer');
        } else {
            $data = [
                'nis' => htmlspecialchars($this->input->post('nis', true)),
                'nama' => htmlspecialchars($this->input->post('name', true)),
                'nama_ortu' => htmlspecialchars($this->input->post('nama_ortu', true)),
                'no_hp' => htmlspecialchars($this->input->post('no_hp', true)),
                'alamat' => htmlspecialchars($this->input->post('alamat', true)),
                'nama_ortu' => htmlspecialchars($this->input->post('nama_ortu', true)),
                'tempat_lahir' => htmlspecialchars($this->input->post('tempat_lahir', true)),
                'asal_sekolah' => htmlspecialchars($this->input->post('asal_sekolah', true)),
                'tgl_lahir' => date($this->input->post('tgl_lahir', true)),
                'email' => htmlspecialchars($this->input->post('email', true)),
                'sekolah' => htmlspecialchars($this->input->post('sekolah', true)),
                'jenis_kelamin' => htmlspecialchars($this->input->post('jenis_kelamin', true)),
                'username' => htmlspecialchars($this->input->post('username', true)),
                'password' => password_hash($this->input->post('password'), PASSWORD_DEFAULT),
                'role_id' => '2',
                'verivikasi' => 0

            ];
            $this->db->insert('regis_siswa', $data);

            redirect('admin');
        }
    }
    //regis admin
    public function registrasiadmin()
    {
        // input registrasi siswa
        $this->form_validation->set_rules('nama', 'Name', 'required|trim');
        $this->form_validation->set_rules('username', 'Username', 'required|trim|is_unique[admin.username]', ['is_unique' => 'Username sudah ada']);
        $this->form_validation->set_rules('password', 'Password', 'required|trim|min_length[3]', ['min_length' => 'Password terlalu pendek']);

        if ($this->form_validation->run() == false) {
            $data['title'] = 'Registrasi Admin';
            $this->load->view('tamplates/auth_header', $data);
            $this->load->view('auth/regisadmin');
            $this->load->view('tamplates/auth_footer');
        } else {
            $data = [
                'nama' => htmlspecialchars($this->input->post('name', true)),
                'username' => htmlspecialchars($this->input->post('username', true)),
                'password' => password_hash($this->input->post('password'), PASSWORD_DEFAULT),

            ];
            $this->db->insert('admin', $data);
            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-info" role="alert">
                Daftar sukses,lanjutkan login!
                </div>'
            );
            redirect('auth');
        }
    }
    public function logout()
    {
        $this->session->unset_userdata('username');
        $this->session->unset_userdata('password');

        $this->session->set_flashdata(
            'message',
            '<div class="alert alert-info" role="alert">
            Berhasil Logout!
            </div>'
        );
        redirect('auth');
    }
    public function blocked()
    {
        $this->load->view('auth/blocked');
    }
}
