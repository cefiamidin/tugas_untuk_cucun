<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if (!$this->db->get_where('admin', ['username' => $this->session->userdata('username')])->row_array()) {
            redirect('auth/blocked');
        }
    }
    public function index()
    {
        $data['title'] = 'Selamat Datang';
        $data['admin'] = $this->db->get_where('admin', ['username' => $this
            ->session->userdata('username')])->row_array();
        $this->load->view('tamplates/header', $data);
        $this->load->view('tamplates/sidebar', $data);
        $this->load->view('tamplates/topbar', $data);
        $this->load->view('admin/index', $data);
        $this->load->view('tamplates/footer');
    }
    //Penilaian

    //PENILAIAN SMP

    public function nilai()
    {
        $data['title'] = 'Penilaian Siswa Baru';
        $data['admin'] = $this->db->get_where('admin', ['username' => $this
            ->session->userdata('username')])->row_array();
        $data['penilaian'] = $this->db->get('penilaian')->result_array();

        $this->load->view('tamplates/header', $data);
        $this->load->view('tamplates/sidebar', $data);
        $this->load->view('tamplates/topbar', $data);
        $this->load->view('admin/penilaian', $data);
        $this->load->view('tamplates/footer');
    }
    public function proses_nilai()
    {

        $data = [
            'nama' => htmlspecialchars($this->input->post('nama', true)),
            'semester1' => htmlspecialchars($this->input->post('semester1', true)),
            'semester2' => htmlspecialchars($this->input->post('semester2', true)),
            'semester3' => htmlspecialchars($this->input->post('semester3', true)),
            'semester4' => htmlspecialchars($this->input->post('semester4', true)),
            'semester5' => htmlspecialchars($this->input->post('semester5', true)),
            'ujian_tertulis' => htmlspecialchars($this->input->post('ujian_tertulis', true)),
            'absensi' => htmlspecialchars($this->input->post('absensi', true))
        ];
        $this->db->insert('penilaian', $data);
        $this->session->set_flashdata(
            'message',
            '<div class="alert alert-info" role="alert">
            Data Berhasil Di Tambahkan,Silahkan Lanjutkan !
            </div>'
        );
        redirect('Admin/nilai');
    }
    // public function deletdata()
    // {
    //     $nama = $this->input->get('nama');
    //     $penilaian = $this->db->get_where('penilaian', ['nama' => 'nama'])->row_array();

    //     //$data['penilaian'] = $this->db->get('penilaian')->result_array();
    //     $this->db->query("DELETE FROM penilaian WHERE nama ='$nama'");
    //     //$this->db->delete('penilaian', ['nama' => $this->session->userdata('nama')])->row_array;
    //     $this->session->set_flashdata(
    //         'message',
    //         '<div class="alert alert-info" role="alert">
    //         Data Berhasil Di Hapus,Silahkan Lanjutkan !
    //         </div>'
    //     );
    //     redirect('Admin/nilai');
    // }

    //PENILAIAN BPI 1

    public function nilaibpi1()
    {
        $data['title'] = 'Penilaian Siswa Baru';
        $data['admin'] = $this->db->get_where('admin', ['username' => $this
            ->session->userdata('username')])->row_array();
        $data['penilaianbpi1'] = $this->db->get('penilaianbpi1')->result_array();
        $total_data = count($data['penilaianbpi1']);

        $this->load->view('tamplates/header', $data);
        $this->load->view('tamplates/sidebar', $data);
        $this->load->view('tamplates/topbar', $data);
        $this->load->view('admin/penilaianbpi1', $data);
        $this->load->view('tamplates/footer');
    }
    public function proses_nilaibpi1()
    {

        $data = [
            'nama' => htmlspecialchars($this->input->post('nama', true)),
            'semester1' => htmlspecialchars($this->input->post('semester1', true)),
            'semester2' => htmlspecialchars($this->input->post('semester2', true)),
            'semester3' => htmlspecialchars($this->input->post('semester3', true)),
            'semester4' => htmlspecialchars($this->input->post('semester4', true)),
            'semester5' => htmlspecialchars($this->input->post('semester5', true)),
            'ujian_tertulis' => htmlspecialchars($this->input->post('ujian_tertulis', true)),
            'absensi' => htmlspecialchars($this->input->post('absensi', true))
        ];
        $this->db->insert('penilaianbpi1', $data);
        $this->session->set_flashdata(
            'message',
            '<div class="alert alert-info" role="alert">
            Data Berhasil Di Tambahkan,Silahkan Lanjutkan !
            </div>'
        );
        redirect('Admin/nilaibpi1');
    }
    //PENILAIAN BPI 2
    public function nilaibpi2()
    {
        $data['title'] = 'Penilaian Siswa Baru';
        $data['admin'] = $this->db->get_where('admin', ['username' => $this
            ->session->userdata('username')])->row_array();
        $data['penilaianbpi2'] = $this->db->get('penilaianbpi2')->result_array();
        $total_data = count($data['penilaianbpi2']);

        $this->load->view('tamplates/header', $data);
        $this->load->view('tamplates/sidebar', $data);
        $this->load->view('tamplates/topbar', $data);
        $this->load->view('admin/penilaianbpi2', $data);
        $this->load->view('tamplates/footer');
    }
    public function proses_nilaibpi2()
    {

        $data = [
            'nama' => htmlspecialchars($this->input->post('nama', true)),
            'semester1' => htmlspecialchars($this->input->post('semester1', true)),
            'semester2' => htmlspecialchars($this->input->post('semester2', true)),
            'semester3' => htmlspecialchars($this->input->post('semester3', true)),
            'semester4' => htmlspecialchars($this->input->post('semester4', true)),
            'semester5' => htmlspecialchars($this->input->post('semester5', true)),
            'ujian_tertulis' => htmlspecialchars($this->input->post('ujian_tertulis', true)),
            'absensi' => htmlspecialchars($this->input->post('absensi', true))
        ];
        $this->db->insert('penilaianbpi2', $data);
        $this->session->set_flashdata(
            'message',
            '<div class="alert alert-info" role="alert">
            Data Berhasil Di Tambahkan,Silahkan Lanjutkan !
            </div>'
        );
        redirect('Admin/nilaibpi2');
    }

    //PENILAIAN BPI 1

    public function nilaismk()
    {
        $data['title'] = 'Penilaian Siswa Baru';
        $data['admin'] = $this->db->get_where('admin', ['username' => $this
            ->session->userdata('username')])->row_array();
        $data['penilaiansmk'] = $this->db->get('penilaiansmk')->result_array();
        $total_data = count($data['penilaiansmk']);


        $this->load->view('tamplates/header', $data);
        $this->load->view('tamplates/sidebar', $data);
        $this->load->view('tamplates/topbar', $data);
        $this->load->view('admin/penilaiansmk', $data);
        $this->load->view('tamplates/footer');
    }
    public function proses_nilaismk()
    {

        $data = [
            'nama' => htmlspecialchars($this->input->post('nama', true)),
            'semester1' => htmlspecialchars($this->input->post('semester1', true)),
            'semester2' => htmlspecialchars($this->input->post('semester2', true)),
            'semester3' => htmlspecialchars($this->input->post('semester3', true)),
            'semester4' => htmlspecialchars($this->input->post('semester4', true)),
            'semester5' => htmlspecialchars($this->input->post('semester5', true)),
            'ujian_tertulis' => htmlspecialchars($this->input->post('ujian_tertulis', true)),
            'absensi' => htmlspecialchars($this->input->post('absensi', true))
        ];
        $this->db->insert('penilaiansmk', $data);
        $this->session->set_flashdata(
            'message',
            '<div class="alert alert-info" role="alert">
            Data Berhasil Di Tambahkan,Silahkan Lanjutkan !
            </div>'
        );
        redirect('Admin/nilaismk');
    }
    //endpenilaian
    ////////////////////EXPORT///////////////////////////////////////
    public function exportpenilaiansmp()
    {
        $data['title'] = 'Penilaian Siswa Baru';
        $data['penilaian'] = $this->db->get('penilaian')->result_array();

        $this->load->view('admin/export/exportpenilaiansmp', $data);
    }
    ////////////////////////////////
    public function exportpenilaianbpi1()
    {
        $data['title'] = 'Penilaian Siswa Baru';
        $data['penilaianbpi1'] = $this->db->get('penilaianbpi1')->result_array();

        $this->load->view('admin/export/exportpenilaianbpi1', $data);
    }
    //////////////////////
    public function exportpenilaianbpi2()
    {
        $data['title'] = 'Penilaian Siswa Baru';
        $data['penilaianbpi2'] = $this->db->get('penilaianbpi2')->result_array();

        $this->load->view('admin/export/exportpenilaianbpi2', $data);
    }
    ///////////////////
    public function exportpenilaiansmk()
    {
        $data['title'] = 'Penilaian Siswa Baru';
        $data['penilaiansmk'] = $this->db->get('penilaiansmk')->result_array();

        $this->load->view('admin/export/exportpenilaiansmk', $data);
    }
    //////////

    /////////////////////////////////////END EXPORT////////////////////////////////////////////////////////////
    public function datatkpg()
    {
        $data['title'] = 'Data Calon Siswa TK - PG BPI Bandung';
        $data['admin'] = $this->db->get_where('admin', ['username' => $this
            ->session->userdata('username')])->row_array();
        $data['regis_siswa'] = $this->db->query("SELECT * FROM regis_siswa where sekolah='TK-PG BPI '")->result_array();
        $this->load->view('tamplates/header', $data);
        $this->load->view('tamplates/sidebar', $data);
        $this->load->view('tamplates/topbar', $data);
        $this->load->view('admin/datatkpg', $data);
        $this->load->view('tamplates/footer');
    }
    public function datatkexport()
    {
        $data['title'] = 'Data Calon Siswa SD BPI Bandung';
        $data['admin'] = $this->db->get_where('admin', ['username' => $this
            ->session->userdata('username')])->row_array();
        $data['regis_siswa'] = $this->db->query("SELECT * FROM regis_siswa where sekolah='TK-PG BPI '")->result_array();
        $this->load->view('admin/export/datatkexport', $data);
    }

    public function datasd()
    {
        $data['title'] = 'Data Calon Siswa SD BPI Bandung';
        $data['admin'] = $this->db->get_where('admin', ['username' => $this
            ->session->userdata('username')])->row_array();
        $data['regis_siswa'] = $this->db->query("SELECT * FROM regis_siswa where sekolah='SD BPI '")->result_array();
        $this->load->view('tamplates/header', $data);
        $this->load->view('tamplates/sidebar', $data);
        $this->load->view('tamplates/topbar', $data);
        $this->load->view('admin/datasd', $data);
        $this->load->view('tamplates/footer');
    }
    public function datasdexport()
    {
        $data['title'] = 'Data Calon Siswa SD BPI Bandung';
        $data['admin'] = $this->db->get_where('admin', ['username' => $this
            ->session->userdata('username')])->row_array();
        $data['regis_siswa'] = $this->db->query("SELECT * FROM regis_siswa where sekolah='SD BPI '")->result_array();
        $this->load->view('admin/export/datasdexport', $data);
    }

    public function datasmp()
    {
        $data['title'] = 'Data Calon Siswa SMP BPI Bandung';
        $data['admin'] = $this->db->get_where('admin', ['username' => $this
            ->session->userdata('username')])->row_array();
        $data['regis_siswa'] = $this->db->query("SELECT * FROM regis_siswa where sekolah='SMP BPI '")->result_array();
        $this->load->view('tamplates/header', $data);
        $this->load->view('tamplates/sidebar', $data);
        $this->load->view('tamplates/topbar', $data);
        $this->load->view('admin/datasmp', $data);
        $this->load->view('tamplates/footer');
    }
    public function datasmpexport()
    {
        $data['title'] = 'Data Calon Siswa SD BPI Bandung';
        $data['admin'] = $this->db->get_where('admin', ['username' => $this
            ->session->userdata('username')])->row_array();
        $data['regis_siswa'] = $this->db->query("SELECT * FROM regis_siswa where sekolah='SMP BPI '")->result_array();
        $this->load->view('admin/export/datasmpexport', $data);
    }

    /////////// BPI 1 data 
    public function datasmabpi1()
    {
        $data['title'] = 'Data Calon Siswa SMA BPI 1 Bandung';
        $data['admin'] = $this->db->get_where('admin', ['username' => $this
            ->session->userdata('username')])->row_array();
        $data['regis_siswa'] = $this->db->query("SELECT * FROM regis_siswa where sekolah='SMA BPI 1'")->result_array();
        $this->load->view('tamplates/header', $data);
        $this->load->view('tamplates/sidebar', $data);
        $this->load->view('tamplates/topbar', $data);
        $this->load->view('admin/datasmabpi1', $data);
        $this->load->view('tamplates/footer');
    }

    public function datasmabpi1export()
    {
        $data['title'] = 'Data Calon Siswa SD BPI Bandung';
        $data['admin'] = $this->db->get_where('admin', ['username' => $this
            ->session->userdata('username')])->row_array();
        $data['regis_siswa'] = $this->db->query("SELECT * FROM regis_siswa where sekolah='SMA BPI 1'")->result_array();
        $this->load->view('admin/export/datasmabpi1export', $data);
    }
    //////////////////////////////////////

    public function datasmabpi2()
    {
        $data['title'] = 'Data Calon Siswa SMA BPI 2 Bandung';
        $data['admin'] = $this->db->get_where('admin', ['username' => $this
            ->session->userdata('username')])->row_array();
        $data['regis_siswa'] = $this->db->query("SELECT * FROM regis_siswa where sekolah='SMA BPI 2'")->result_array();
        $this->load->view('tamplates/header', $data);
        $this->load->view('tamplates/sidebar', $data);
        $this->load->view('tamplates/topbar', $data);
        $this->load->view('admin/datasmabpi2', $data);
        $this->load->view('tamplates/footer');
    }
    public function datasmabpi2export()
    {
        $data['title'] = 'Data Calon Siswa SD BPI Bandung';
        $data['admin'] = $this->db->get_where('admin', ['username' => $this
            ->session->userdata('username')])->row_array();
        $data['regis_siswa'] = $this->db->query("SELECT * FROM regis_siswa where sekolah='SMA BPI 2'")->result_array();
        $this->load->view('admin/export/datasmabpi2export', $data);
    }

    public function datasmk()
    {
        $data['title'] = 'Data Calon Siswa SMK BPI Bandung';
        $data['admin'] = $this->db->get_where('admin', ['username' => $this
            ->session->userdata('username')])->row_array();
        $data['regis_siswa'] = $this->db->query("SELECT * FROM regis_siswa where sekolah='SMK BPI'")->result_array();
        $this->load->view('tamplates/header', $data);
        $this->load->view('tamplates/sidebar', $data);
        $this->load->view('tamplates/topbar', $data);
        $this->load->view('admin/datasmk', $data);
        $this->load->view('tamplates/footer');
    }
    public function datasmkexport()
    {
        $data['title'] = 'Data Calon Siswa SD BPI Bandung';
        $data['admin'] = $this->db->get_where('admin', ['username' => $this
            ->session->userdata('username')])->row_array();
        $data['regis_siswa'] = $this->db->query("SELECT * FROM regis_siswa where sekolah='SMK BPI'")->result_array();
        $this->load->view('admin/export/datasmkexport', $data);
    }

    public function tkbpi()
    {
        $data['title'] = 'Informasi Mengenai PG - TK BPI';
        $data['admin'] = $this->db->get_where('admin', ['username' => $this
            ->session->userdata('username')])->row_array();
        $data['regis_siswa'] = $this->db->get('regis_siswa')->result_array();

        $this->load->view('tamplates/header', $data);
        $this->load->view('tamplates/sidebar', $data);
        $this->load->view('tamplates/topbar', $data);
        $this->load->view('admin/tkbpi', $data);
        $this->load->view('tamplates/footer');
    }
    public function sdbpi()
    {
        $data['title'] = 'Informasi Mengenai SD BPI';
        $data['admin'] = $this->db->get_where('admin', ['username' => $this
            ->session->userdata('username')])->row_array();
        $data['regis_siswa'] = $this->db->get('regis_siswa')->result_array();

        $this->load->view('tamplates/header', $data);
        $this->load->view('tamplates/sidebar', $data);
        $this->load->view('tamplates/topbar', $data);
        $this->load->view('admin/sdbpi', $data);
        $this->load->view('tamplates/footer');
    }
    public function smpbpi()
    {
        $data['title'] = 'Informasi Mengenai SMP BPI';
        $data['admin'] = $this->db->get_where('admin', ['username' => $this
            ->session->userdata('username')])->row_array();
        $data['regis_siswa'] = $this->db->get('regis_siswa')->result_array();

        $this->load->view('tamplates/header', $data);
        $this->load->view('tamplates/sidebar', $data);
        $this->load->view('tamplates/topbar', $data);
        $this->load->view('admin/smpbpi', $data);
        $this->load->view('tamplates/footer');
    }
    public function smabpi1()
    {
        $data['title'] = 'Informasi Mengenai SMA BPI 1';
        $data['admin'] = $this->db->get_where('admin', ['username' => $this
            ->session->userdata('username')])->row_array();
        $data['regis_siswa'] = $this->db->get('regis_siswa')->result_array();

        $this->load->view('tamplates/header', $data);
        $this->load->view('tamplates/sidebar', $data);
        $this->load->view('tamplates/topbar', $data);
        $this->load->view('admin/smabpi1', $data);
        $this->load->view('tamplates/footer');
    }
    public function smabpi2()
    {
        $data['title'] = 'Informasi Mengenai SMA BPI 2';
        $data['admin'] = $this->db->get_where('admin', ['username' => $this
            ->session->userdata('username')])->row_array();
        $data['regis_siswa'] = $this->db->get('regis_siswa')->result_array();

        $this->load->view('tamplates/header', $data);
        $this->load->view('tamplates/sidebar', $data);
        $this->load->view('tamplates/topbar', $data);
        $this->load->view('admin/smabpi2', $data);
        $this->load->view('tamplates/footer');
    }
    public function smkbpi()
    {
        $data['title'] = 'Informasi Mengenai SMK BPI';
        $data['admin'] = $this->db->get_where('admin', ['username' => $this
            ->session->userdata('username')])->row_array();
        $data['regis_siswa'] = $this->db->get('regis_siswa')->result_array();

        $this->load->view('tamplates/header', $data);
        $this->load->view('tamplates/sidebar', $data);
        $this->load->view('tamplates/topbar', $data);
        $this->load->view('admin/smkbpi', $data);
        $this->load->view('tamplates/footer');
    }
    public function petunjuk()
    {
        $data['title'] = 'Petunjuk';
        $data['admin'] = $this->db->get_where('admin', ['username' => $this
            ->session->userdata('username')])->row_array();
        $data['regis_siswa'] = $this->db->get('regis_siswa')->result_array();

        $this->load->view('tamplates/header', $data);
        $this->load->view('tamplates/sidebar', $data);
        $this->load->view('tamplates/topbar', $data);
        $this->load->view('admin/petunjuk', $data);
        $this->load->view('tamplates/footer');
    }
    public function pengumuman()
    {
        $data['title'] = 'Pengumuman';
        $data['admin'] = $this->db->get_where('admin', ['username' => $this
            ->session->userdata('username')])->row_array();
        $data['pengumuman'] = $this->db->get('pengumuman')->result_array();

        $this->load->view('tamplates/header', $data);
        $this->load->view('tamplates/sidebar', $data);
        $this->load->view('tamplates/topbar', $data);
        $this->load->view('admin/pengumuman', $data);
        $this->load->view('tamplates/footer');
    }
    public function buatpengumuman()
    {

        $data['title'] = 'Buat Pengumuman';
        $data['admin'] = $this->db->get_where('admin', ['username' => $this
            ->session->userdata('username')])->row_array();
        $this->load->view('tamplates/header', $data);
        $this->load->view('tamplates/sidebar', $data);
        $this->load->view('tamplates/topbar', $data);
        $this->load->view('admin/index', $data);
        $this->load->view('tamplates/footer');
    }
    public function prosespengumuman()
    {
        $data = [
            'untuk' => htmlspecialchars($this->input->post('untuk', true)),
            'buat_pengumuman' => htmlspecialchars($this->input->post('buat_pengumuman', true))

        ];
        $this->db->insert('pengumuman', $data);
        $this->session->set_flashdata(
            'message',
            '<div class="alert alert-info" role="alert">
            Pengumuman Berhasil Di Tambahkan,silahkan cek menu Pengumuman
            </div>'
        );
        redirect('admin');
    }
    public function logout()
    {
        $this->session->unset_userdata('username');
        $this->session->unset_userdata('password');

        $this->session->set_flashdata(
            'message',
            '<div class="alert alert-info" role="alert">
            Berhasil Logout!
            </div>'
        );
        redirect('auth');
    }
}
