<?php

use function PHPSTORM_META\type;

defined('BASEPATH') or exit('No direct script access allowed');

class Halamanutama extends CI_Controller
{
    public function index()
    {
        $data['title'] = 'Selamat Datang';
        $this->load->view('tamplates/utama/headeru', $data);
        $this->load->view('tamplates/utama/sidebaru', $data);
        $this->load->view('tamplates/utama/topbaru', $data);
        $this->load->view('utama/index', $data);
        $this->load->view('tamplates/utama/footeru');
    }
    public function tkbpi()
    {
        $data['title'] = 'Informasi Mengenai PG - TK BPI';
        $this->load->view('tamplates/utama/headeru', $data);
        $this->load->view('tamplates/utama/sidebaru', $data);
        $this->load->view('tamplates/utama/topbaru', $data);
        $this->load->view('utama/tkbpi', $data);
        $this->load->view('tamplates/utama/footeru');
    }
    public function sdbpi()
    {
        $data['title'] = 'Informasi Mengenai SD BPI';
        $this->load->view('tamplates/utama/headeru', $data);
        $this->load->view('tamplates/utama/sidebaru', $data);
        $this->load->view('tamplates/utama/topbaru', $data);
        $this->load->view('utama/sdbpi', $data);
        $this->load->view('tamplates/utama/footeru');
    }
    public function smpbpi()
    {
        $data['title'] = 'Informasi Mengenai SMP BPI';
        $this->load->view('tamplates/utama/headeru', $data);
        $this->load->view('tamplates/utama/sidebaru', $data);
        $this->load->view('tamplates/utama/topbaru', $data);
        $this->load->view('utama/smpbpi', $data);
        $this->load->view('tamplates/utama/footeru');
    }
    public function smabpi1()
    {
        $data['title'] = 'Informasi Mengenai SMA BPI 1';
        $this->load->view('tamplates/utama/headeru', $data);
        $this->load->view('tamplates/utama/sidebaru', $data);
        $this->load->view('tamplates/utama/topbaru', $data);
        $this->load->view('utama/smabpi1', $data);
        $this->load->view('tamplates/utama/footeru');
    }
    public function smabpi2()
    {
        $data['title'] = 'Informasi Mengenai SMA BPI 2';
        $this->load->view('tamplates/utama/headeru', $data);
        $this->load->view('tamplates/utama/sidebaru', $data);
        $this->load->view('tamplates/utama/topbaru', $data);
        $this->load->view('utama/smabpi2', $data);
        $this->load->view('tamplates/utama/footeru');
    }
    public function smkbpi()
    {
        $data['title'] = 'Informasi Mengenai SMK BPI';
        $this->load->view('tamplates/utama/headeru', $data);
        $this->load->view('tamplates/utama/sidebaru', $data);
        $this->load->view('tamplates/utama/topbaru', $data);
        $this->load->view('utama/smkbpi', $data);
        $this->load->view('tamplates/utama/footeru');
    }
    public function petunjuk()
    {
        $data['title'] = 'Petunjuk';
        $this->load->view('tamplates/utama/headeru', $data);
        $this->load->view('tamplates/utama/sidebaru', $data);
        $this->load->view('tamplates/utama/topbaru', $data);
        $this->load->view('utama/petunjuk', $data);
        $this->load->view('tamplates/utama/footeru');
    }
    public function registrasi()
    {
        $this->form_validation->set_rules('nama', 'nama', 'required|trim');
        $this->form_validation->set_rules('nama_ortu', 'nama_ortu', 'required|trim');
        $this->form_validation->set_rules('no_hp', 'no_hp', 'required|trim');
        $this->form_validation->set_rules('jenis_kelamin', 'jenis_kelamin', 'required|trim');
        $this->form_validation->set_rules('alamat', 'alamat', 'required|trim');
        $this->form_validation->set_rules('tempat_lahir', 'tempat_lahir', 'required|trim');
        $this->form_validation->set_rules('asal_sekolah', 'asal_sekolah', 'required|trim');
        $this->form_validation->set_rules('tgl_lahir', 'tgl_lahir', 'required|trim');
        $this->form_validation->set_rules('email', 'email', 'required|trim');
        $this->form_validation->set_rules('sekolah', 'sekolah', 'required|trim');
        $this->form_validation->set_rules('username', 'username', 'required|trim');
        $this->form_validation->set_rules('password', 'password', 'required|trim');
        $data['title'] = 'Registrasi';
        $this->load->view('tamplates/utama/headeru', $data);
        $this->load->view('tamplates/utama/sidebaru', $data);
        $this->load->view('tamplates/utama/topbaru', $data);
        $this->load->view('utama/index', $data);
        $this->load->view('tamplates/utama/footeru');
    }
    public function prosesregistrasi()
    {
        $email = $this->input->post('email', true);
        $data = [
            'nis' => htmlspecialchars($this->input->post('nis', true)),
            'nama' => htmlspecialchars($this->input->post('name', true)),
            'nama_ortu' => htmlspecialchars($this->input->post('nama_ortu', true)),
            'no_hp' => htmlspecialchars($this->input->post('no_hp', true)),
            'alamat' => htmlspecialchars($this->input->post('alamat', true)),
            'nama_ortu' => htmlspecialchars($this->input->post('nama_ortu', true)),
            'tempat_lahir' => htmlspecialchars($this->input->post('tempat_lahir', true)),
            'asal_sekolah' => htmlspecialchars($this->input->post('asal_sekolah', true)),
            'tgl_lahir' => date($this->input->post('tgl_lahir', true)),
            'email' => htmlspecialchars($email),
            'sekolah' => htmlspecialchars($this->input->post('sekolah', true)),
            'jenis_kelamin' => htmlspecialchars($this->input->post('jenis_kelamin', true)),
            'username' => htmlspecialchars($this->input->post('username', true)),
            'password' => password_hash($this->input->post('password'), PASSWORD_DEFAULT),
            'role_id' => '2',
            'verifikasi' => 0,

        ];

        //token 
        $token = base64_encode(random_bytes(32));
        $user_token = [
            'email' => $email,
            'token' => $token,
            'date_created' => time()
        ];


        $this->db->insert('regis_siswa', $data);
        $this->db->insert('user_token', $user_token);

        $this->_sendEmail($token, 'verify');

        $this->session->set_flashdata(
            'message',
            '<div class="alert alert-info" role="alert">
            Mohon Aktifasi Akun Anda Terlebih Dahulu
            </div>'
        );
        redirect('Halamanutama');
    }

    private function _sendEmail($token, $type)
    {
        $config = [
            'protocol'  => 'smtp',
            'smtp_host' => 'ssl://smtp.googlemail.com',
            'smtp_user' => 'yayasanbpippdb@gmail.com',
            'smtp_pass' => 'Yayasanbpi123',
            'smtp_port' => 465,
            'mailtype'  => 'html',
            'charset'   => 'utf-8',
            'newline'   => "\r\n"
        ];
        //$this->load->library('email', $config);
        $this->email->initialize($config);

        $this->email->from('yayasanbpippdb@gmail.com', 'Yayasan BPI Bandung');
        $this->email->to($this->input->post('email'));

        if ($type == 'verify') {
            $this->email->subject('Verifikasi Akun');
            $this->email->message('klik link tersebut untuk verifikasi : <a href="'
                . base_url() . 'halamanutama/verify?email=' . $this->input->post('email') . '&token=' . urlencode($token) . '">Aktivasi</a>');
        } elseif ($type == ('lupapw')) {
            $this->email->subject('Reset Password');
            $this->email->message('klik link tersebut untuk Reset Password : <a href="'
                . base_url() . 'halamanutama/resetpassword?email=' . $this->input->post('email')
                . '&token=' . urlencode($token) . '">Reset Password</a>');
        }

        if ($this->email->send()) {
            return true;
        } else {
            echo $this->email->print_debugger();
            die;
        }
    }
    public function verify()
    {
        $email = $this->input->get('email');
        $token = $this->input->get('token');

        $regis_siswa = $this->db->get_where('regis_siswa', ['email' => $email])->row_array();
        if ($regis_siswa) {

            $user_token = $this->db->get_where('user_token', ['token' => $token])->row_array();

            if ($user_token) {

                if (time() - $user_token['date_created'] < (60 * 60 * 24)) {

                    $this->db->set('verifikasi', 1);
                    $this->db->where('email', $email);
                    $this->db->update('regis_siswa');


                    $this->db->delete('user_token', ['email' => $email]);

                    $this->session->set_flashdata(
                        'message',
                        '<div class="alert alert-success" role="alert">
                        ' . $email . ' Sudah Diverifikasi, please Login.
                        </div>'
                    );
                    redirect('halamanutama');
                } else {


                    $this->db->delete('regis_siswa', ['email' => $email]);
                    $this->db->get_where()('regis_siswa', ['verifikasi' => 'tidak aktif']);
                    $this->db->delete('user_token', ['email' => $email]);

                    $this->session->set_flashdata(
                        'message',
                        '<div class="alert alert-danger" role="alert">
                        Token expired.
                        </div>'
                    );
                    redirect('halamanutama');
                }
            } else {
                $this->session->set_flashdata(
                    'message',
                    '<div class="alert alert-danger" role="alert">
                    Token infalid
                    </div>'
                );
                redirect('halamanutama');
            }
        } else {
            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-danger" role="alert">
            akun gagal di verifikasi!
            </div>'
            );
            redirect('halamanutama');
        }
    }
    public function lupapassword()
    {
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
        if ($this->form_validation->run() == false) {
            $data['title'] = 'Lupa Password';
            $this->load->view('tamplates/auth_header', $data);
            $this->load->view('auth/lupapassword');
            $this->load->view('tamplates/auth_footer');
        } else {
            $email = $this->input->post('email');
            $lupapw = $this->db->get_where('regis_siswa', ['email' => $email, 'verifikasi' => 1])->row_array();

            if ($lupapw) {
                $token = base64_encode(random_bytes(32));
                $user_token = [
                    'email' => $email,
                    'token' => $token,
                    'date_created' => time()
                ];
                $this->db->insert('user_token', $user_token);
                $this->_sendEmail($token, 'lupapw');

                $this->session->set_flashdata(
                    'message',
                    '<div class="alert alert-success" role="alert">
                    Periksa Email Anda Untuk Reset Password
                    </div>'
                );
                redirect('halamanutama/lupapassword');
            } else {
                $this->session->set_flashdata(
                    'message',
                    '<div class="alert alert-danger" role="alert">
                    Email Belum terdaftar atau belum verifikasi
                    </div>'
                );
                redirect('halamanutama/lupapassword');
            }
        }
    }

    public function resetpassword()
    {
        $email = $this->input->get('email');
        $token = $this->input->get('token');

        $regis_siswa = $this->db->get_where('regis_siswa', ['email' => $email])->row_array();


        if ($regis_siswa) {
            $user_token = $this->db->get_where('user_token', ['token' => $token])
                ->row_array();

            if ($user_token) {

                $this->session->set_userdata('reset_email', $email);
                $this->changePassword();
            } else {

                $this->session->set_flashdata(
                    'message',
                    '<div class="alert alert-danger" role="alert">
                         Token Salah
                        </div>'
                );
                redirect('auth');
            }
        } else {
            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-danger" role="alert">
                 Reset Password gagal!
                </div>'
            );
            redirect('auth');
        }
    }
    public function changePassword()
    {
        if (!$this->session->userdata('reset_email')) {
            redirect('auth');
        }
        $this->form_validation->set_rules(
            'password1',
            'password',
            'trim|required|min_length[3]|matches[password2]'
        );
        $this->form_validation->set_rules(
            'password2',
            'repeat password',
            'trim|required|min_length[3]|matches[password1]'
        );
        if ($this->form_validation->run() == false) {

            $data['title'] = 'Chaange Password';
            $this->load->view('tamplates/auth_header', $data);
            $this->load->view('auth/changepassword');
            $this->load->view('tamplates/auth_footer');
        } else {
            $password = password_hash(
                $this->input->post('password1'),
                PASSWORD_DEFAULT
            );
            $email = $this->session->userdata('reset_email');

            $this->db->set('password', $password);
            $this->db->where('email', $email);
            $this->db->update('regis_siswa');


            $this->session->unset_userdata('reset_email');
            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-success" role="alert">
                 Password Berhasil Diubah
                </div>'
            );
            redirect('auth');
        }
    }
}
