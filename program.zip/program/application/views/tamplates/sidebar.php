        <!-- Sidebar -->
        <?php
        $this->form_validation->set_rules('username', 'Username', 'required|trim|is_unique[admin.username]', ['is_unique' => 'Username sudah ada']);
        $this->form_validation->set_rules('password', 'Password', 'required|trim|min_length[3]', ['min_length' => 'Password terlalu pendek']); ?>
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?= base_url('admin/index') ?>">
                <div class="sidebar-brand-icon">
                    <i class="fas fa-school"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Yayasan BPI</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">


            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="<?= base_url('admin/index') ?>">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Menu Utama
                    </span></a>
            </li>
            <div class="sidebar-heading">
                Menu Admin
            </div>
            <!-- Nav Item - Buat Pengumuman -->
            <li class="nav-item active">
                <a class="nav-link" href="<?= base_url('admin/buatpengumuman') ?>" data-toggle="modal" data-target="#pengumumanModal">
                    <i class="fas fa-fw fa-bullhorn"></i>
                    <span>Buat Pengumuman</span></a>
            </li>
            <!-- Nav Item - Nilai -->
            <li class="nav-item active">
                <a class="nav-link" data-toggle="collapse" data-target="#menu1" aria-expanded="true" aria-controls="menu1">
                    <i class="fas fa-fw fa-desktop"></i>
                    <span>Masukan Nilai</span></a>
                <div id="menu1" class="collapse show" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Penilaian</h6>
                        <a class="collapse-item" href="<?= base_url('admin/nilai') ?>">SMP BPI</a>
                        <a class="collapse-item" href="<?= base_url('admin/nilaibpi1') ?>">SMA BPI 1</a>
                        <a class="collapse-item" href="<?= base_url('admin/nilaibpi2') ?>">SMA BPI 2</a>
                        <a class="collapse-item" href="<?= base_url('admin/nilaismk') ?>">SMK BPI</a>
                    </div>
                </div>

            </li>
            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                user
            </div>
            <!-- Nav Item - Tables -->
            <li class="nav-item active">
                <a class="nav-link" href="<?= base_url('admin/pengumuman') ?>" data-toggle="pengumuman" data-target="#pengumumanModal">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Pengumuman</span></a>
            </li>

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item active">
                <a class="nav-link" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="true" aria-controls="collapsePages">
                    <i class="fas fa-fw fa-folder"></i>
                    <span>Data Siswa</span>
                </a>
                <div id="collapsePages" class="collapse show" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Calon Siswa</h6>
                        <a class="collapse-item" href="<?= base_url('admin/datatkpg') ?>">PG/TK-A/TK-B</a>
                        <a class="collapse-item" href="<?= base_url('admin/datasd') ?>">SD BPI</a>
                        <a class="collapse-item" href="<?= base_url('admin/datasmp') ?>">SMP BPI</a>
                        <a class="collapse-item" href="<?= base_url('admin/datasmabpi1') ?>">SMA BPI 1</a>
                        <a class="collapse-item" href="<?= base_url('admin/datasmabpi2') ?>">SMA BPI 2</a>
                        <a class="collapse-item" href="<?= base_url('admin/datasmk') ?>">SMK BPI</a>
                    </div>
                </div>
            </li>



            <!-- Nav Item - Petunjukn -->
            <li class="nav-item active">
                <a class="nav-link" href="<?= base_url('admin/petunjuk') ?>">
                    <i class="far fa-fw fa-question-circle"></i>
                    <span>Petunjuk</span></a>
            </li>
            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <!-- Dasbord -->

        <!-- End of Sidebar -->


        <!-- Modal -->
        <div class="modal fade" id="pengumumanModal" tabindex="-1" role="dialog" aria-labelledby="#pengumumanModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="pengumumanModalLabel">Buat Pengumuman</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form class="user" method="POST" action="<?= base_url('Admin/prosespengumuman') ?>">
                        <div class="modal-body">
                            <div class="form-group">
                                <input type="text" class="form-control form-control-user" id="untuk" name="untuk" placeholder="untuk" value="<?= set_value('untuk') ?>">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control form-control-user" id="buat_pengumuman" name="buat_pengumuman" placeholder="Tulis Pengumuman" value="<?= set_value('buat_pengumuman') ?>">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="Submit" class="btn btn-primary">Buat</button>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>