        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?= base_url('halamanutama') ?>">
                <div class="sidebar-brand-icon">
                    <i class="fas fa-school"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Yayasan BPI</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">


            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="<?= base_url('halamanutama') ?>">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Menu Utama

                    </span></a>
            </li>
            <!-- Divider -->
            <hr class="sidebar-divider">
            <!--pendaftaran-->
            <li class="nav-item active">
                <a class="nav-link" href="" data-toggle="modal" data-target="#daftarModal">
                    <i class="fas fa-fw fa-plus-circle"></i>
                    <span>pendaftaran</span>
                </a>

            </li>


            <!-- Nav Item - Petunjukn -->
            <li class="nav-item active">
                <a class="nav-link" href="<?= base_url('halamanutama/petunjuk') ?>">
                    <i class="far fa-fw fa-question-circle"></i>
                    <span>Petunjuk</span></a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="<?= base_url('auth') ?>">
                    <i class="fas fa-sign-in-alt"></i>
                    <span>Login</span></a>
            </li>
            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <!-- Dasbord -->

        <!-- End of Sidebar -->

        <!-- Modal pendaftaran-->
        <div class="modal fade" id="daftarModal" tabindex="-1" role="dialog" aria-labelledby="daftarModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="daftarModalLabel">Pendaftaran Siswa Baru</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form class="user" method="POST" action="<?= base_url('halamanutama/prosesregistrasi') ?>">
                        <div class="modal-body">
                            <div class="form-group">
                                <font size='1'>Untuk tk-pg dan SD <font size='1' color='red'>tidak wajib di isi</font> beri saja -
                                </font>
                                <input type="text" class="form-control " id="nis" name="nis" placeholder="NIS" value="<?= set_value('nis') ?>">
                            </div>
                            <div class="form-group">

                                <input type="text" class="form-control " id="name" name="name" placeholder="Nama" value="<?= set_value('name') ?>">
                                <?= form_error('nama', '<small class="text-danger pl-3">', '</small>'); ?>
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control " id="nama_ortu" name="nama_ortu" placeholder="Nama Orang Tua" value="<?= set_value('nama_ortu') ?>">
                            </div>

                            <input type="text" class="form-control " id="no_hp" name="no_hp" placeholder="Nomor HP" value="<?= set_value('no_hp') ?>">


                            <div class="form-group">
                                <font size='1'>Isi Alamat Dengan Lengkap
                                </font>
                                <textarea class="form-control " id="alamat" name="alamat" placeholder="Alamat Lengkap" value="<?= set_value('alamat') ?>"></textarea>

                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control " id="tempat_lahir" name="tempat_lahir" placeholder="Tempat Lahir" value="<?= set_value('tempat_lahir') ?>">

                            </div>

                            <input type="date" class="form-control " id="tgl_lahir" name="tgl_lahir" placeholder="Tanggal Lahir" value="<?= set_value('tgl_lahir') ?>">


                            <font size='1'>Untuk TK-PG dan SD <font size='1' color='red'>tidak wajib di isi</font> beri saja -
                            </font>
                            <input type="text" class="form-control " id="asal_sekolah" name="asal_sekolah" placeholder="Asal Sekolah" value="<?= set_value('asal_sekolah') ?>">

                            <div class="form-group">
                                <font size='1'>Pastikan email yang digunakan <font size='1' color='red'>AKTIF</font> untuk verifikasi
                                </font>
                                <input type="text" class="form-control " id="email" name="email" placeholder="Alamat email" value="<?= set_value('email') ?>">
                            </div>
                            <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <label class="input-group-text" for="inputGroupSelect01">Pilih</label>
                                </div>
                                <select class="custom-select" id="sekolah" name="sekolah" value="<?= set_value('sekolah') ?>">
                                    <option selected>Sekolah yang dituju</option>
                                    <option value="Tk-PG BPI">Tk-PG BPI</option>
                                    <option value="SD BPI">SD BPI</option>
                                    <option value="SMP BPI">SMP BPI</option>
                                    <option value="SMA BPI 1">SMA BPI 1</option>
                                    <option value="SMA BPI 2">SMA BPI 2</option>
                                    <option value="SMK BPI">SMK BPI </option>
                                </select>
                            </div>
                            <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <label class="input-group-text" for="inputGroupSelect01">Pilih</label>
                                </div>
                                <select class="custom-select" id="jenis_kelamin" name="jenis_kelamin" value="<?= set_value('jenis_kelamin') ?>">
                                    <option selected>Jenis Kelamin</option>
                                    <option value="L">Laki-Laki</option>
                                    <option value="P">Perempuan</option>
                                </select>
                            </div>
                            <div class="form-group">

                                <input type="text" class="form-control" id="username" name="username" placeholder="Username" value="<?= set_value('username') ?>">

                            </div>

                            <input type="password" class="form-control" id="password" name="password" placeholder="Password">

                            <p>
                                <font size='1'> Harap di ingat - ingat untuk username dan password</font>
                            </p>

                        </div>
                        <div class="modal-footer">
                            <button type="Submit" class="btn btn-primary">Daftar</button>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>