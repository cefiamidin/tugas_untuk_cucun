 <!-- Begin Page Content -->
 <div class="container-fluid">

     <!-- Page Heading -->
     <a class="sidebar-brand d-flex align-items-center justify-content-center"></a>
     <div>
         <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>
     </div>
     <table>
         </tr>
         <td>
             <!-- Earnings (Monthly) Card Example -->

             <div class="card">
                 <div class="card-body">
                     <div class="row no-gutters align-items-center">
                         <div class="col mr-2">
                             <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Pendaftaran</div>
                             <div class="h5 mb-0 font-weight-bold text-gray-800">Rp.300.000</div>
                         </div>

                     </div>
                 </div>
             </div>

         </td>
         <td>
             <!-- Earnings (Monthly) Card Example -->
             <div class="card">
                 <div class="card-body">
                     <div class="row no-gutters align-items-center">
                         <div class="col mr-2">
                             <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">DSP</div>
                             <div class="h5 mb-0 font-weight-bold text-gray-800">Rp. 4,600,000</div>
                         </div>

                     </div>
                 </div>
             </div>

         </td>
         <td>

             <!-- Earnings (Monthly) Card Example -->

             <div class="card">
                 <div class="card-body">
                     <div class="row no-gutters align-items-center">
                         <div class="col mr-2">
                             <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">PP</div>
                             <div class="h5 mb-0 font-weight-bold text-gray-800">Rp. 1,500,000</div>
                         </div>

                     </div>
                 </div>
             </div>
         <td>
             <!-- Earnings (Monthly) Card Example -->

             <div class="card">
                 <div class="card-body">
                     <div class="row no-gutters align-items-center">
                         <div class="col mr-2">
                             <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">SPP Pertama</div>
                             <div class="h5 mb-0 font-weight-bold text-gray-800">Rp. 450.000</div>
                         </div>

                     </div>
                 </div>
             </div>

         </td>
         </td>
         </td>
         </tr>
     </table>
     <table>
         <tr>
             <td>
                 <div class="card ">
                     <div class="card-header text-center">
                         Informasi Sekolah
                     </div>
                     <div class="card-body">
                         <p class="card-text">Lokasi Sekolah :
                             Jl. Burangrang no 8 Kota Bandung 40262
                             Telepon : (022) 7301739</p>
                         <p class="card-text">Informasi :</p>
                         <p class="card-text">Ade Aso S.Pd | 0812 2078 8068</p>
                         <p class="card-text">Tatang M.Pd | 0838 2903 7146</p>
                         <p class="card-text">Yayan Himawan S.Pd, MM.Pd | 0821 1635 9966</p>
                         <p class="card-text">Acep Komarudin S.Si | 0838 2108 157</p>
                         <p class="card-text">Doni Agus Maulana S.Pd | 0898 6922 119</p>
                         <p class="card-text">Annisa Rahmayanti S.Pd | 0811 2220 308</p>
                         <p class="card-text">Dra Anggani | 0896 1009 3005</p>
                     </div>
                 </div>
             </td>
             <td>
                 <div class="card ">
                     <div class="card-header text-center">
                         Dokumen yang harus disiapkan
                     </div>
                     <div class="card-body">
                         <p class="card-text">1. Akte Kelahiran</p>
                         <p class="card-text">2. KTP Ayah tua/Wali</p>
                         <p class="card-text">3. Kartu Keluarga</p>
                         <p class="card-text">4. Surat Kelakuan Baik</p>
                     </div>
                 </div>
             </td>

         </tr>
         <table>

 </div>
 <center>
     <a href="<?= base_url('halamanutama') ?>">Kembali Kehalaman Utama</a>
 </center>
 </div>

 <!-- /.container-fluid -->