 <!-- Begin Page Content -->
 <div class="container-fluid">

     <!-- Page Heading -->
     <a class="sidebar-brand d-flex align-items-center justify-content-center"></a>
     <div>
         <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>
     </div>
     <div class="card shadow mb-4">
         <div class="card-header py-3">
             <h6 class="m-0 font-weight-bold text-primary">Data Siswa</h6>
         </div>
         <div class="card-body">
             <div class="table-responsive">
                 <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                     <div class="row">
                         <div class="col-lg-16">
                             <table class="table table-hover">
                                 <thead>
                                     <tr>
                                         <th scope="col">NO</th>
                                         <th scope="col">Nama</th>
                                         <th scope="col">Sekolah Asal</th>
                                         <th scope="col">Jenis Kelamin</th>
                                         <th scope="col">Sekolah Yang Dituju</th>
                                     </tr>
                                 </thead>
                                 <tbody>
                                     <?php $i = 1; ?>
                                     <?php foreach ($regis_siswa as $regis) : ?>
                                         <tr>
                                             <th scope="row"><?= $i; ?></th>
                                             <td><?= $regis['nama'];  ?></td>
                                             <td><?= $regis['asal_sekolah'];  ?></td>
                                             <td><?= $regis['jenis_kelamin'];  ?></td>
                                             <td><?= $regis['sekolah'];  ?></td>

                                         </tr>
                                         <?php $i++ ?>
                                     <?php endforeach; ?>
                             </table>
                         </div>
                     </div>
             </div>
         </div>

         <!-- /.container-fluid -->