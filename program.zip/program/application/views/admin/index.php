 <!-- Begin Page Content -->
 <div class="container-fluid">

     <!-- Page Heading -->
     <a class="sidebar-brand d-flex align-items-center justify-content-center"></a>
     <div>
         <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>
     </div>
     <?= $this->session->flashdata('message'); ?>
     <table>
         <tr>
             <td>
                 <div class="card" style="width: 18rem;">
                     <div class="card-body">
                         <h5 class="card-title">TK - PG BPI</h5>
                         <p class="card-text">Lokasi Sekolah :
                             Jl. Halimun No.23 Kota Bandung 40262
                             Telepon: (022) 7307518</p>
                         <a href="<?= base_url('admin/tkbpi') ?>" class="btn btn-primary">More Info</a>
                     </div>
                 </div>
             </td>
             <td>
                 <div class="card" style="width: 18rem;">
                     <div class="card-body">
                         <h5 class="card-title">SD BPI Bandung</h5>
                         <p class="card-text">Lokasi Sekolah :
                             Jl. Halimun No.40 Kota Bandung 40263
                             Telepon: (022) 7301460</p>
                         <a href="<?= base_url('admin/sdbpi') ?>" class="btn btn-primary">More Info</a>
                     </div>
                 </div>
             </td>
             <td>
                 <div class="card" style="width: 18rem;">
                     <div class="card-body">
                         <h5 class="card-title">SMP BPI Bandung</h5>
                         <p class="card-text">Lokasi Sekolah :
                             Jl. Burangrang no 8 Kota Bandung 40262
                             Telepon : (022) 7301739</p>
                         <a href="<?= base_url('admin/smpbpi') ?>" class="btn btn-primary">More Info</a>
                     </div>
                 </div>
             </td>
         </tr>
         <tr>
             <td>
                 <div class="card" style="width: 18rem;">
                     <div class="card-body">
                         <h5 class="card-title">SMA BPI 1 Bandung</h5>
                         <p class="card-text">Lokasi Sekolah :
                             Jl. Burangrang no 8 Kota Bandung 40262
                             Telepon : (022) 7301739</p>
                         <a href="<?= base_url('admin/smabpi1') ?>" class="btn btn-primary">More Info</a>
                     </div>
                 </div>
             </td>
             <td>
                 <div class="card" style="width: 18rem;">
                     <div class="card-body">
                         <h5 class="card-title">SMA BPI 2 Bandung</h5>
                         <p class="card-text">Lokasi Sekolah :
                             Jl. Burangrang no 8 Kota Bandung 40262
                             Telepon : (022) 7301739</p>
                         <a href="<?= base_url('admin/smabpi2') ?>" class="btn btn-primary">More Info</a>
                     </div>
                 </div>
             </td>
             <td>
                 <div class="card" style="width: 18rem;">
                     <div class="card-body">
                         <h5 class="card-title">SMK BPI Bandung</h5>
                         <p class="card-text">Lokasi Sekolah :
                             Jl. Burangrang no 8 Kota Bandung 40262
                             Telepon : (022) 7301739</p>
                         <a href="<?= base_url('admin/smkbpi') ?>" class="btn btn-primary">More Info</a>
                     </div>
                 </div>
             </td>
         </tr>
     </table>
 </div>
 <div class="card ">
     <div class="card-header text-center">
         Sekertariat Yayasan BPI Bandung
     </div>
     <div class="card-body">
         <p class="card-text">
             Jl. Burangrang no 8 Bandung 40262 | Telepon : (022)7301739</p>
         <p class="card-text">Jl. Halimun No.40 Bandung 40263 | Telepon : (022) 7301460</p>
         <p class="card-text">Jl. Halimun No.23 Bandung 40262 | Telepon : (022) 7307518</p>
     </div>
 </div>
 <div>
     <div class="card-footer text-muted text-center">
         Yayasan BPI Bandung
     </div>
 </div>
 </div>

 <!-- /.container-fluid -->