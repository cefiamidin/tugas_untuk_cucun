 <!-- Begin Page Content -->
 <div class="container-fluid">

     <!-- Page Heading -->
     <a class="sidebar-brand d-flex align-items-center justify-content-center"></a>
     <div>
         <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>
     </div>
     <table>
         </tr>
         <td>
             <!-- Earnings (Monthly) Card Example -->

             <div class="card">
                 <div class="card-body">
                     <div class="row no-gutters align-items-center">
                         <div class="col mr-2">
                             <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Pendaftaran</div>
                             <div class="h5 mb-0 font-weight-bold text-gray-800">Rp.300.000</div>
                         </div>

                     </div>
                 </div>
             </div>

         </td>
         <td>
             <!-- Earnings (Monthly) Card Example -->
             <div class="card">
                 <div class="card-body">
                     <div class="row no-gutters align-items-center">
                         <div class="col mr-2">
                             <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">DSP</div>
                             <div class="h5 mb-0 font-weight-bold text-gray-800">Rp. 10,370,000</div>
                         </div>

                     </div>
                 </div>
             </div>

         </td>
         <td>

             <!-- Earnings (Monthly) Card Example -->

             <div class="card">
                 <div class="card-body">
                     <div class="row no-gutters align-items-center">
                         <div class="col mr-2">
                             <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">PP</div>
                             <div class="h5 mb-0 font-weight-bold text-gray-800">Rp. 1,650,000</div>
                         </div>

                     </div>
                 </div>
             </div>
         <td>
             <!-- Earnings (Monthly) Card Example -->

             <div class="card">
                 <div class="card-body">
                     <div class="row no-gutters align-items-center">
                         <div class="col mr-2">
                             <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">SPP Pertama</div>
                             <div class="h5 mb-0 font-weight-bold text-gray-800">Rp. 650.000</div>
                         </div>

                     </div>
                 </div>
             </div>

         </td>
         </td>
         </td>
         </tr>
     </table>
     <table>
         <tr>
             <td>
                 <div class="card ">
                     <div class="card-header text-center">
                         Informasi Sekolah
                     </div>
                     <div class="card-body">
                         <p class="card-text">Lokasi Sekolah :
                             Jl. Burangrang no 8 Kota Bandung 40262
                             Telepon : (022) 7301739</p>
                         <p class="card-text">Informasi :</p>
                         <p class="card-text">Dida Faridasari | 0813 2056 1272</p>
                         <p class="card-text">Dwi Rina, S.Pd | 0857 2141 5354</p>
                         <p class="card-text">Mela Rosanti, S.Pd | 0857 2046 2818</p>
                         <p class="card-text">Putri Rani, S.Pd | 0858 6089 1994</p>
                         <p class="card-text">M. Bardiansyah, M.Pd | 0896 5607 7573</p>
                         <p class="card-text">Asep Dian Insan Fadila, S.Pd | 0812 1802 6812</p>
                     </div>
                 </div>
             </td>
             <td>
                 <div class="card ">
                     <div class="card-header text-center">
                         Dokumen yang harus disiapkan
                     </div>
                     <div class="card-body">
                         <p class="card-text">1. Akte Kelahiran</p>
                         <p class="card-text">2. KTP Ayah tua/Wali</p>
                         <p class="card-text">3. Kartu Keluarga</p>
                     </div>
                 </div>
             </td>

         </tr>
         <table>

 </div>
 </div>

 <!-- /.container-fluid -->