 <!-- Begin Page Content -->
 <div class="container-fluid">

     <!-- Page Heading -->
     <a class="sidebar-brand d-flex align-items-center justify-content-center"></a>
     <div>
         <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>
     </div>
     <table>
         </tr>
         <td>
             <!-- Earnings (Monthly) Card Example -->

             <div class="card">
                 <div class="card-body">
                     <div class="row no-gutters align-items-center">
                         <div class="col mr-2">
                             <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Pendaftaran</div>
                             <div class="h5 mb-0 font-weight-bold text-gray-800">Rp.300.000</div>
                         </div>

                     </div>
                 </div>
             </div>

         </td>
         <td>
             <!-- Earnings (Monthly) Card Example -->
             <div class="card">
                 <div class="card-body">
                     <div class="row no-gutters align-items-center">
                         <div class="col mr-2">
                             <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">DSP</div>
                             <div class="h5 mb-0 font-weight-bold text-gray-800">Rp. 10,005,000</div>
                         </div>

                     </div>
                 </div>
             </div>

         </td>
         <td>

             <!-- Earnings (Monthly) Card Example -->

             <div class="card">
                 <div class="card-body">
                     <div class="row no-gutters align-items-center">
                         <div class="col mr-2">
                             <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">PP</div>
                             <div class="h5 mb-0 font-weight-bold text-gray-800">Rp. 1,200,000</div>
                         </div>

                     </div>
                 </div>
             </div>
         <td>
             <!-- Earnings (Monthly) Card Example -->

             <div class="card">
                 <div class="card-body">
                     <div class="row no-gutters align-items-center">
                         <div class="col mr-2">
                             <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">SPP Pertama</div>
                             <div class="h5 mb-0 font-weight-bold text-gray-800">Rp. 680.000</div>
                         </div>

                     </div>
                 </div>
             </div>

         </td>
         </td>
         </td>
         </tr>
     </table>
     <table>
         <tr>
             <td>
                 <div class="card ">
                     <div class="card-header text-center">
                         Informasi Sekolah
                     </div>
                     <div class="card-body">
                         <p class="card-text">Lokasi Sekolah :
                             Jl. Halimun No.40 Kota Bandung 40263
                             Telepon: (022) 7301460</p>
                         <p class="card-text">Informasi :</p>
                         <p class="card-text">Ety Juariah S.E. | 0821 2007 9637</p>
                         <p class="card-text">Sugiharto S.Pd | 0812 2132 228</p>
                         <p class="card-text">Dra Nikeu Kusnantini | 0821 2612 6325</p>
                         <p class="card-text">Rini Trisnawulan S.S | 0858 6182 8848</p>
                     </div>
                 </div>
             </td>
             <td>
                 <div class="card ">
                     <div class="card-header text-center">
                         Dokumen yang harus disiapkan
                     </div>
                     <div class="card-body">
                         <p class="card-text">1. Akte Kelahiran</p>
                         <p class="card-text">2. KTP Orang tua/Wali</p>
                         <p class="card-text">3. Kartu Keluarga</p>
                     </div>
                 </div>
             </td>

         </tr>
         <table>

 </div>
 </div>

 <!-- /.container-fluid -->