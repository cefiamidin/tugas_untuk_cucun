 <!-- Begin Page Content -->
 <div class="container-fluid">

     <!-- Page Heading -->
     <a class="sidebar-brand d-flex align-items-center justify-content-center"></a>
     <div>
         <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>
     </div>
     <table>
         </tr>
         <td>
             <!-- Earnings (Monthly) Card Example -->

             <div class="card">
                 <div class="card-body">
                     <div class="row no-gutters align-items-center">
                         <div class="col mr-2">
                             <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Pendaftaran</div>
                             <div class="h5 mb-0 font-weight-bold text-gray-800">Rp.300.000</div>
                         </div>

                     </div>
                 </div>
             </div>

         </td>
         <td>
             <!-- Earnings (Monthly) Card Example -->
             <div class="card">
                 <div class="card-body">
                     <div class="row no-gutters align-items-center">
                         <div class="col mr-2">
                             <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">DSP</div>
                             <div class="h5 mb-0 font-weight-bold text-gray-800">Rp. 11,925,000</div>
                         </div>

                     </div>
                 </div>
             </div>

         </td>
         <td>

             <!-- Earnings (Monthly) Card Example -->

             <div class="card">
                 <div class="card-body">
                     <div class="row no-gutters align-items-center">
                         <div class="col mr-2">
                             <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">PP</div>
                             <div class="h5 mb-0 font-weight-bold text-gray-800">Rp. 1,750,000</div>
                         </div>

                     </div>
                 </div>
             </div>
         <td>
             <!-- Earnings (Monthly) Card Example -->

             <div class="card">
                 <div class="card-body">
                     <div class="row no-gutters align-items-center">
                         <div class="col mr-2">
                             <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">SPP Pertama</div>
                             <div class="h5 mb-0 font-weight-bold text-gray-800">Rp. 860.000</div>
                         </div>

                     </div>
                 </div>
             </div>

         </td>
         </td>
         </td>
         </tr>
     </table>
     <table>
         <tr>
             <td>
                 <div class="card ">
                     <div class="card-header text-center">
                         Informasi Sekolah
                     </div>
                     <div class="card-body">
                         <p class="card-text">Lokasi Sekolah :
                             Jl. Burangrang no 8 Kota Bandung 40262
                             Telepon : (022) 7301739</p>
                         <p class="card-text">Informasi :</p>
                         <p class="card-text">Asep Anwar Sanusi S.Pd | 0813 2001 4658</p>
                         <p class="card-text">Nurwulan Afriliani S.Pd | 0852 2017 3499</p>
                         <p class="card-text">Lies Sabariah M.M.Pd | 0822 1519 5970
                             | 0812 2331 0063</p>
                         <p class="card-text">Asri Indah Wulandari S.Pd | 0817 9489 489</p>
                         <p class="card-text">Eka Tri | 0819 1066 2851</p>
                         <p class="card-text">Kelik Sunardi | 0812 2144 5354</p>
                     </div>
                 </div>
             </td>
             <td>
                 <div class="card ">
                     <div class="card-header text-center">
                         Dokumen yang harus disiapkan
                     </div>
                     <div class="card-body">
                         <p class="card-text">1. Akte Kelahiran</p>
                         <p class="card-text">2. KTP Ayah tua/Wali</p>
                         <p class="card-text">3. Kartu Keluarga</p>
                     </div>
                 </div>
             </td>

         </tr>
         <table>

 </div>
 </div>

 <!-- /.container-fluid -->