<?php
header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=Data Siswa Baru SD BPI.xls");
?>
<table class="table table-hover">
    <tr>
        <th scope="col">NO</th>
        <th scope="col">NIS</th>
        <th scope="col">Nama</th>
        <th scope="col">Sekolah</th>
        <th scope="col">Alamat</th>
        <th scope="col">Nama Orang tua</th>
        <th scope="col">Nomor HP</th>
        <th scope="col">Tempat Lahir</th>
        <th scope="col">Tanggal Lahir</th>
        <th scope="col">Asal Sekolah</th>
    </tr>
    </thead>
    <tbody>
        <?php $i = 1; ?>
        <?php foreach ($regis_siswa as $regis) : ?>
            <tr>
                <th scope="row"><?= $i; ?></th>
                <td><?= $regis['nis'];  ?></td>
                <td><?= $regis['nama'];  ?></td>
                <td><?= $regis['sekolah'];  ?></td>
                <td><?= $regis['alamat'];  ?></td>
                <td><?= $regis['nama_ortu'];  ?></td>
                <td><?= $regis['no_hp'];  ?></td>
                <td><?= $regis['tempat_lahir'];  ?></td>
                <td><?= $regis['tgl_lahir'];  ?></td>
                <td><?= $regis['asal_sekolah'];  ?></td>
            </tr>
            <?php $i++ ?>
        <?php endforeach; ?>
</table>