<?php
header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=Data Siswa Baru TK - PG BPI.xls");
?>
<table class="table table-hover">
    <thead>
        <tr>
            <th scope="col">NO</th>
            <th scope="col">Nama</th>
            <th scope="col">Sekolah Asal</th>
            <th scope="col">Jenis Kelamin</th>
            <th scope="col">Sekolah Yang Dituju</th>

        </tr>
    </thead>
    <tbody>
        <?php $i = 1; ?>
        <?php foreach ($regis_siswa as $regis) : ?>
            <tr>
                <th scope="row"><?= $i; ?></th>
                <td><?= $regis['nama'];  ?></td>
                <td><?= $regis['asal_sekolah'];  ?></td>
                <td><?= $regis['jenis_kelamin'];  ?></td>
                <td><?= $regis['sekolah'];  ?></td>

            </tr>
            <?php $i++ ?>
        <?php endforeach; ?>
</table>