<?php
header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=Data Penerimaan BPI 2.xls");
?>
<?php
$data4['penilaianbpi2'] = $this->db->get('penilaianbpi2')->result_array();
$total_data = count($data4['penilaianbpi2']);
$Rmax1 = 0;
$Rmax2 = 0;
$Rmax3 = 0;
$Rmax4 = 0;
$Rmax5 = 0;
$Rmax6 = 0;
$Rmax7 = 0;
//RC1
for ($i = 0; $i < $total_data; $i++) {
    // loop data nilai
    $smt1 = $data4['penilaianbpi2'][$i]['semester1'];
    //end loop
    if ($i < $total_data) {
        if ($smt1 >= $Rmax1) {
            $Rmax1 = $smt1;
        } else {
            $Rmax1 = $Rmax1;
        }
    }
}
//validasi nilai
if ($Rmax1 < 60) {
    $Rmax1 = 1;
} elseif ($Rmax1 >= 60 && $Rmax1 <= 69) {
    $Rmax1 = 2;
} elseif ($Rmax1 >= 70 && $Rmax1 <= 84) {
    $Rmax1 = 3;
} else {
    $Rmax1 = 4;
}
//end validasi
$Rc1 = array();
for ($j = 0; $j < $total_data; $j++) {
    $nsmt1 = $data4['penilaianbpi2'][$j]['semester1'];
    if ($nsmt1 < 60) {
        $nsmt1 = 1;
    } elseif ($nsmt1 >= 60 && $nsmt1 <= 69) {
        $nsmt1 = 2;
    } elseif ($nsmt1 >= 70 && $nsmt1 <= 84) {
        $nsmt1 = 3;
    } else {
        $nsmt1 = 4;
    }
    array_push($Rc1, $nsmt1 / $Rmax1 * 1);
}
//END RC1
//RC2
for ($a = 0; $a < $total_data; $a++) {
    // loop data nilai
    $smt2 = $data4['penilaianbpi2'][$a]['semester2'];
    //end loop
    if ($a < $total_data) {
        if ($smt2 >= $Rmax2) {
            $Rmax2 = $smt2;
        } else {
            $Rmax2 = $Rmax2;
        }
    }
}
//validasi nilai
if ($Rmax2 < 60) {
    $Rmax2 = 1;
} elseif ($Rmax2 >= 60 && $Rmax2 <= 69) {
    $Rmax1 = 2;
} elseif ($Rmax2 >= 70 && $Rmax2 <= 84) {
    $Rmax2 = 3;
} else {
    $Rmax2 = 4;
}
//end validasi
$Rc2 = array();
for ($a = 0; $a < $total_data; $a++) {
    $nsmt2 = $data4['penilaianbpi2'][$a]['semester2'];
    if ($nsmt2 < 60) {
        $nsmt2 = 1;
    } elseif ($nsmt2 >= 60 && $nsmt2 <= 69) {
        $nsmt1 = 2;
    } elseif ($nsmt2 >= 70 && $nsmt2 <= 84) {
        $nsmt2 = 3;
    } else {
        $nsmt2 = 4;
    }
    array_push($Rc2, $nsmt2 / $Rmax2 * 1);
}

//END RC2
//RC3
for ($c = 0; $c < $total_data; $c++) {
    // loop data nilai
    $smt3 = $data4['penilaianbpi2'][$c]['semester3'];
    //end loop
    if ($c < $total_data) {
        if ($smt3 >= $Rmax3) {
            $Rmax3 = $smt2;
        } else {
            $Rmax3 = $Rmax3;
        }
    }
}
//validasi nilai
if ($Rmax3 < 60) {
    $Rmax3 = 1;
} elseif ($Rmax3 >= 60 && $Rmax3 <= 69) {
    $Rmax1 = 2;
} elseif ($Rmax3 >= 70 && $Rmax3 <= 84) {
    $Rmax3 = 3;
} else {
    $Rmax3 = 4;
}
//end validasi
$Rc3 = array();
for ($c = 0; $c < $total_data; $c++) {
    $nsmt3 = $data4['penilaianbpi2'][$c]['semester3'];
    if ($nsmt3 < 60) {
        $nsmt3 = 1;
    } elseif ($nsmt3 >= 60 && $nsmt3 <= 69) {
        $nsmt3 = 2;
    } elseif ($nsmt3 >= 70 && $nsmt3 <= 84) {
        $nsmt3 = 3;
    } else {
        $nsmt3 = 4;
    }
    array_push($Rc3, $nsmt3 / $Rmax3 * 1);
}
//END RC3
//RC4
for ($i = 0; $i < $total_data; $i++) {
    // loop data nilai
    $smt4 = $data4['penilaianbpi2'][$i]['semester4'];
    //end loop
    if ($i < $total_data) {
        if ($smt4 >= $Rmax4) {
            $Rmax4 = $smt4;
        } else {
            $Rmax4 = $Rmax4;
        }
    }
}
//validasi nilai
if ($Rmax4 < 60) {
    $Rmax4 = 1;
} elseif ($Rmax4 >= 60 && $Rmax4 <= 69) {
    $Rmax4 = 2;
} elseif ($Rmax4 >= 70 && $Rmax4 <= 84) {
    $Rmax4 = 3;
} else {
    $Rmax4 = 4;
}
//end validasi
$Rc4 = array();
for ($j = 0; $j < $total_data; $j++) {
    $nsmt4 = $data4['penilaianbpi2'][$j]['semester1'];
    if ($nsmt4 < 60) {
        $nsmt4 = 1;
    } elseif ($nsmt4 >= 60 && $nsmt4 <= 69) {
        $nsmt4 = 2;
    } elseif ($nsmt4 >= 70 && $nsmt4 <= 84) {
        $nsmt4 = 3;
    } else {
        $nsmt4 = 4;
    }
    array_push($Rc4, $nsmt4 / $Rmax4 * 1);
}
//END RC4
//RC5
for ($g = 0; $g < $total_data; $g++) {
    // loop data nilai
    $smt5 = $data4['penilaianbpi2'][$g]['semester5'];
    //end loop
    if ($g < $total_data) {
        if ($smt5 >= $Rmax5) {
            $Rmax5 = $smt5;
        } else {
            $Rmax5 = $Rmax5;
        }
    }
}
//validasi nilai
if ($Rmax5 < 60) {
    $Rmax5 = 1;
} elseif ($Rmax5 >= 60 && $Rmax5 <= 69) {
    $Rmax1 = 2;
} elseif ($Rmax5 >= 70 && $Rmax5 <= 84) {
    $Rmax5 = 3;
} else {
    $Rmax5 = 4;
}
//end validasi
$Rc5 = array();
for ($g = 0; $g < $total_data; $g++) {
    $nsmt5 = $data4['penilaianbpi2'][$g]['semester5'];
    if ($nsmt5 < 60) {
        $nsmt5 = 1;
    } elseif ($nsmt5 >= 60 && $nsmt5 <= 69) {
        $nsmt5 = 2;
    } elseif ($nsmt5 >= 70 && $nsmt5 <= 84) {
        $nsmt5 = 3;
    } else {
        $nsmt5 = 4;
    }
    array_push($Rc5, $nsmt5 / $Rmax5 * 1);
}
//END RC5
//RC6
for ($k = 0; $k < $total_data; $k++) {
    // loop data nilai
    $nilaia = $data4['penilaianbpi2'][$k]['ujian_tertulis'];
    //end loop
    if ($k < $total_data) {
        if ($nilaia >= $Rmax6) {
            $Rmax6 = $nilaia;
        } else {
            $Rmax6 = $Rmax6;
        }
    }
}
//validasi nilai
if ($Rmax6 < 60) {
    $Rmax6 = 1;
} elseif ($Rmax6 >= 60 && $Rmax6 <= 69) {
    $Rmax1 = 2;
} elseif ($Rmax6 >= 70 && $Rmax6 <= 84) {
    $Rmax6 = 3;
} else {
    $Rmax6 = 4;
}
//end validasi
$Rc6 = array();
for ($k = 0; $k < $total_data; $k++) {
    $nsmt6 = $data4['penilaianbpi2'][$k]['ujian_tertulis'];
    if ($nsmt6 < 60) {
        $nsmt6 = 1;
    } elseif ($nsmt6 >= 60 && $nsmt6 <= 69) {
        $nsmt3 = 2;
    } elseif ($nsmt6 >= 70 && $nsmt6 <= 84) {
        $nsmt6 = 3;
    } else {
        $nsmt6 = 4;
    }
    array_push($Rc6, $nsmt6 / $Rmax6 * 3);
}
//END RC6
//RC7
$Rmax7 = 0;
for ($i = 0; $i < $total_data; $i++) {
    // loop data nilai
    $smt7 = $data4['penilaianbpi2'][$i]['absensi'];
    //end loop
    if ($i < $total_data) {
        if ($smt7 >= $Rmax7) {
            $Rmax7 = $smt7;
        } elseif ($smt7 < $Rmax7) {
            $Rmax7 = $Rmax7;
        }
    }
}
$Rc7 = array();
for ($j = 0; $j < $total_data; $j++) {
    $nsmt7 = $data4['penilaianbpi2'][$j]['absensi'];

    array_push($Rc7, $nsmt7 / $Rmax7 * 2);
}
//END RC7
$arr_nilai_akhir = array();
for ($i = 0; $i < $total_data; $i++) {
    $nilai_akhir = $Rc1[$i] + $Rc2[$i] + $Rc3[$i] + $Rc4[$i] + $Rc5[$i] + $Rc6[$i] + $Rc7[$i];
    if ($nilai_akhir < 7) {

        $nilai_akhir = 'Ditolak';
    } elseif ($nilai_akhir > 7) {

        $nilai_akhir = 'Diterima';
    }
    array_push($arr_nilai_akhir, $nilai_akhir);
    //var_dump($nilai_akhir);
    // echo "<br><br>";
}
?>
<table class="table table-hover">
    <thead>
        <tr>
            <th scope="col">NO</th>
            <th scope="col">Nama</th>
            <th scope="col">Keterangan</th>

        </tr>
    </thead>
    <tbody>
        <?php $i = 1; ?>
        <?php foreach ($penilaianbpi2 as $nilai) : ?>
            <tr>
                <th scope="row"><?= $i; ?></th>
                <td><?= $nilai['nama'];  ?></td>
                <td><?= $arr_nilai_akhir[$i - 1];  ?></td>
            </tr>
            <?php $i++ ?>
        <?php endforeach; ?>
</table>