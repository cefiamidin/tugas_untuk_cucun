<?php
header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=Data Siswa Baru SMA BPI 1.xls");
?>
<table class="table table-hover">

    <thead>
        <tr>
            <th scope="col">NO</th>
            <th scope="col">NIS</th>
            <th scope="col">Nama</th>
            <th scope="col">Sekolah Asal</th>
            <th scope="col">Jenis Kelamin</th>
            <th scope="col">Sekolah Yang Dituju</th>
            <th scope="col">Nama Orang tua</th>
            <th scope="col">No HP</th>
            <th scope="col">Alamat</th>
            <th scope="col">Tanggal Lahir</th>
            <th scope="col">Tempat Lahir</th>

        </tr>
    </thead>
    <tbody>
        <?php $i = 1; ?>
        <?php foreach ($regis_siswa as $regis) : ?>
            <tr>
                <th scope="row"><?= $i; ?></th>
                <td><?= $regis['nis'];  ?></td>
                <td><?= $regis['nama'];  ?></td>
                <td><?= $regis['asal_sekolah'];  ?></td>
                <td><?= $regis['jenis_kelamin'];  ?></td>
                <td><?= $regis['sekolah'];  ?></td>
                <td><?= $regis['nama_ortu'];  ?></td>
                <td><?= $regis['no_hp'];  ?></td>
                <td><?= $regis['alamat'];  ?></td>
                <td><?= $regis['tgl_lahir'];  ?></td>
                <td><?= $regis['tempat_lahir'];  ?></td>
            </tr>
            <?php $i++ ?>
        <?php endforeach; ?>

</table>