 <!-- Begin Page Content -->
 <div class="container-fluid">

     <!-- Page Heading -->
     <div class="card-body">
         <div class="table-responsive">
             <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                 <div class="row">
                     <div class="col-lg-16">
                         <table class="table table-hover">
                             <thead>
                                 <tr>
                                     <th scope="col">NO</th>
                                     <th scope="col">Nama</th>
                                 </tr>
                             </thead>
                             <tbody>
                                 <tr>
                                     <th>1</th>
                                     <td>Masuk/Buka website PPDB Yayasan BPI Bandung</td>
                                 </tr>
                                 <tr>
                                     <th>2</th>
                                     <td>Klik Menu "Pendaftaran yang ada di menu sidebar"</td>
                                 </tr>
                                 <tr>
                                     <th>3</th>
                                     <td>Login ke Aplikasi untuk melihat pengumuman selanjutnya jika sudah melakukan daftar </td>
                                 </tr>
                                 <tr>
                                     <th>4</th>
                                     <td>Memantau website PPDB Yayasan Bpi Bandung</td>
                                 </tr>
                                 <tr>
                                     <th>5</th>
                                     <td>Menunggu konfirmasi Diterima/Ditolak</td>
                                 </tr>
                                 <tr>
                                     <th>6</th>
                                     <td>Setelah Diterima menunggu info untuk mengumpulkan berkas dan pembayaran ke setiap unitnya</td>
                                 </tr>
                                 <tr>
                                     <th>7</th>
                                     <td>Lakukan login langsung jika punya akun</td>
                                 </tr>
                             </tbody>
                         </table>
                     </div>
                 </div>
         </div>
         <center>
             <a href="<?= base_url('halamanutama') ?>">Kembali Kehalaman Utama</a>
         </center>

         <!-- /.container-fluid -->