 <!-- Begin Page Content -->
 <div class="container-fluid">

     <!-- Page Heading -->
     <a class="sidebar-brand d-flex align-items-center justify-content-center"></a>
     <div>
         <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>
     </div>
     <table>
         </tr>
         <td>
             <!-- Earnings (Monthly) Card Example -->

             <div class="card">
                 <div class="card-body">
                     <div class="row no-gutters align-items-center">
                         <div class="col mr-2">
                             <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Pendaftaran</div>
                             <div class="h5 mb-0 font-weight-bold text-gray-800">Rp.300,000</div>
                         </div>

                     </div>
                 </div>
             </div>

         </td>
         <td>
             <!-- Earnings (Monthly) Card Example -->
             <div class="card">
                 <div class="card-body">
                     <div class="row no-gutters align-items-center">
                         <div class="col mr-2">
                             <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">DSP</div>
                             <div class="h5 mb-0 font-weight-bold text-gray-800">Rp. 8,245,000</div>
                         </div>

                     </div>
                 </div>
             </div>

         </td>
         <td>
             <!-- Earnings (Monthly) Card Example -->

             <div class="card">
                 <div class="card-body">
                     <div class="row no-gutters align-items-center">
                         <div class="col mr-2">
                             <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Kegiatan</div>
                             <div class="h5 mb-0 font-weight-bold text-gray-800">Rp. 1.000.000</div>
                         </div>

                     </div>
                 </div>
             </div>
         <td>

             <!-- Earnings (Monthly) Card Example -->

             <div class="card">
                 <div class="card-body">
                     <div class="row no-gutters align-items-center">
                         <div class="col mr-2">
                             <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">PP</div>
                             <div class="h5 mb-0 font-weight-bold text-gray-800">Rp. 1.300.000</div>
                         </div>

                     </div>
                 </div>
             </div>
         <td>
             <!-- Earnings (Monthly) Card Example -->

             <div class="card">
                 <div class="card-body">
                     <div class="row no-gutters align-items-center">
                         <div class="col mr-2">
                             <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">SPP Pertama</div>
                             <div class="h5 mb-0 font-weight-bold text-gray-800">Rp. 680.000</div>
                         </div>

                     </div>
                 </div>
             </div>

         </td>
         </td>
         </td>
         </tr>
     </table>
     <table>
         <tr>
             <td>
                 <div class="card ">
                     <div class="card-header text-center">
                         Informasi Sekolah
                     </div>
                     <div class="card-body">
                         <p class="card-text">Lokasi Sekolah :
                             Jl. Halimun No.23 Kota Bandung 40262
                             Telepon: (022) 7307518</p>
                         <p class="card-text">Informasi :</p>
                         <p class="card-text">Sri Mulyati,S.Pd AUD | 0819 31452627</p>
                         <p class="card-text">Maya Arifin A.Md | 0813 94511100</p>
                         <p class="card-text">Sari Damayanti,S.Pd AUD | 0878 25130273</p>
                     </div>
                 </div>
             </td>
             <td>
                 <div class="card ">
                     <div class="card-header text-center">
                         Dokumen yang harus disiapkan
                     </div>
                     <div class="card-body">
                         <p class="card-text">1. Akte Kelahiran</p>
                         <p class="card-text">2. KTP Orang tua/Wali</p>
                         <p class="card-text">3. Kartu Keluarga</p>
                     </div>
                 </div>
             </td>

         </tr>
         <table>

 </div>
 </div>

 <!-- /.container-fluid -->