<?php
$data4['penilaianbpi1'] = $this->db->get('penilaianbpi1')->result_array();
$total_data = count($data4['penilaianbpi1']);
$Rmax1 = 0;
$Rmax2 = 0;
$Rmax3 = 0;
$Rmax4 = 0;
$Rmax5 = 0;
$Rmax6 = 0;
$Rmax7 = 0;
//RC1
for ($i = 0; $i < $total_data; $i++) {
    // loop data nilai
    $smt1 = $data4['penilaianbpi1'][$i]['semester1'];
    //end loop
    if ($i < $total_data) {
        if ($smt1 >= $Rmax1) {
            $Rmax1 = $smt1;
        } else {
            $Rmax1 = $Rmax1;
        }
    }
}
//validasi nilai
if ($Rmax1 < 60) {
    $Rmax1 = 1;
} elseif ($Rmax1 >= 60 && $Rmax1 <= 69) {
    $Rmax1 = 2;
} elseif ($Rmax1 >= 70 && $Rmax1 <= 84) {
    $Rmax1 = 3;
} else {
    $Rmax1 = 4;
}
//end validasi
$Rc1 = array();
for ($j = 0; $j < $total_data; $j++) {
    $nsmt1 = $data4['penilaianbpi1'][$j]['semester1'];
    if ($nsmt1 < 60) {
        $nsmt1 = 1;
    } elseif ($nsmt1 >= 60 && $nsmt1 <= 69) {
        $nsmt1 = 2;
    } elseif ($nsmt1 >= 70 && $nsmt1 <= 84) {
        $nsmt1 = 3;
    } else {
        $nsmt1 = 4;
    }
    array_push($Rc1, $nsmt1 / $Rmax1 * 1);
}
//END RC1
//RC2
for ($a = 0; $a < $total_data; $a++) {
    // loop data nilai
    $smt2 = $data4['penilaianbpi1'][$a]['semester2'];
    //end loop
    if ($a < $total_data) {
        if ($smt2 >= $Rmax2) {
            $Rmax2 = $smt2;
        } else {
            $Rmax2 = $Rmax2;
        }
    }
}
//validasi nilai
if ($Rmax2 < 60) {
    $Rmax2 = 1;
} elseif ($Rmax2 >= 60 && $Rmax2 <= 69) {
    $Rmax1 = 2;
} elseif ($Rmax2 >= 70 && $Rmax2 <= 84) {
    $Rmax2 = 3;
} else {
    $Rmax2 = 4;
}
//end validasi
$Rc2 = array();
for ($a = 0; $a < $total_data; $a++) {
    $nsmt2 = $data4['penilaianbpi1'][$a]['semester2'];
    if ($nsmt2 < 60) {
        $nsmt2 = 1;
    } elseif ($nsmt2 >= 60 && $nsmt2 <= 69) {
        $nsmt1 = 2;
    } elseif ($nsmt2 >= 70 && $nsmt2 <= 84) {
        $nsmt2 = 3;
    } else {
        $nsmt2 = 4;
    }
    array_push($Rc2, $nsmt2 / $Rmax2 * 1);
}

//END RC2
//RC3
for ($c = 0; $c < $total_data; $c++) {
    // loop data nilai
    $smt3 = $data4['penilaianbpi1'][$c]['semester3'];
    //end loop
    if ($c < $total_data) {
        if ($smt3 >= $Rmax3) {
            $Rmax3 = $smt2;
        } else {
            $Rmax3 = $Rmax3;
        }
    }
}
//validasi nilai
if ($Rmax3 < 60) {
    $Rmax3 = 1;
} elseif ($Rmax3 >= 60 && $Rmax3 <= 69) {
    $Rmax1 = 2;
} elseif ($Rmax3 >= 70 && $Rmax3 <= 84) {
    $Rmax3 = 3;
} else {
    $Rmax3 = 4;
}
//end validasi
$Rc3 = array();
for ($c = 0; $c < $total_data; $c++) {
    $nsmt3 = $data4['penilaianbpi1'][$c]['semester3'];
    if ($nsmt3 < 60) {
        $nsmt3 = 1;
    } elseif ($nsmt3 >= 60 && $nsmt3 <= 69) {
        $nsmt3 = 2;
    } elseif ($nsmt3 >= 70 && $nsmt3 <= 84) {
        $nsmt3 = 3;
    } else {
        $nsmt3 = 4;
    }
    array_push($Rc3, $nsmt3 / $Rmax3 * 1);
}
//END RC3
//RC4
for ($i = 0; $i < $total_data; $i++) {
    // loop data nilai
    $smt4 = $data4['penilaianbpi1'][$i]['semester4'];
    //end loop
    if ($i < $total_data) {
        if ($smt4 >= $Rmax4) {
            $Rmax4 = $smt4;
        } else {
            $Rmax4 = $Rmax4;
        }
    }
}
//validasi nilai
if ($Rmax4 < 60) {
    $Rmax4 = 1;
} elseif ($Rmax4 >= 60 && $Rmax4 <= 69) {
    $Rmax4 = 2;
} elseif ($Rmax4 >= 70 && $Rmax4 <= 84) {
    $Rmax4 = 3;
} else {
    $Rmax4 = 4;
}
//end validasi
$Rc4 = array();
for ($j = 0; $j < $total_data; $j++) {
    $nsmt4 = $data4['penilaianbpi1'][$j]['semester1'];
    if ($nsmt4 < 60) {
        $nsmt4 = 1;
    } elseif ($nsmt4 >= 60 && $nsmt4 <= 69) {
        $nsmt4 = 2;
    } elseif ($nsmt4 >= 70 && $nsmt4 <= 84) {
        $nsmt4 = 3;
    } else {
        $nsmt4 = 4;
    }
    array_push($Rc4, $nsmt4 / $Rmax4 * 1);
}
//END RC4
//RC5
for ($g = 0; $g < $total_data; $g++) {
    // loop data nilai
    $smt5 = $data4['penilaianbpi1'][$g]['semester5'];
    //end loop
    if ($g < $total_data) {
        if ($smt5 >= $Rmax5) {
            $Rmax5 = $smt5;
        } else {
            $Rmax5 = $Rmax5;
        }
    }
}
//validasi nilai
if ($Rmax5 < 60) {
    $Rmax5 = 1;
} elseif ($Rmax5 >= 60 && $Rmax5 <= 69) {
    $Rmax1 = 2;
} elseif ($Rmax5 >= 70 && $Rmax5 <= 84) {
    $Rmax5 = 3;
} else {
    $Rmax5 = 4;
}
//end validasi
$Rc5 = array();
for ($g = 0; $g < $total_data; $g++) {
    $nsmt5 = $data4['penilaianbpi1'][$g]['semester5'];
    if ($nsmt5 < 60) {
        $nsmt5 = 1;
    } elseif ($nsmt5 >= 60 && $nsmt5 <= 69) {
        $nsmt5 = 2;
    } elseif ($nsmt5 >= 70 && $nsmt5 <= 84) {
        $nsmt5 = 3;
    } else {
        $nsmt5 = 4;
    }
    array_push($Rc5, $nsmt5 / $Rmax5 * 1);
}
//END RC5
//RC6
for ($k = 0; $k < $total_data; $k++) {
    // loop data nilai
    $nilaia = $data4['penilaianbpi1'][$k]['ujian_tertulis'];
    //end loop
    if ($k < $total_data) {
        if ($nilaia >= $Rmax6) {
            $Rmax6 = $nilaia;
        } else {
            $Rmax6 = $Rmax6;
        }
    }
}
//validasi nilai
if ($Rmax6 < 60) {
    $Rmax6 = 1;
} elseif ($Rmax6 >= 60 && $Rmax6 <= 69) {
    $Rmax1 = 2;
} elseif ($Rmax6 >= 70 && $Rmax6 <= 84) {
    $Rmax6 = 3;
} else {
    $Rmax6 = 4;
}
//end validasi
$Rc6 = array();
for ($k = 0; $k < $total_data; $k++) {
    $nsmt6 = $data4['penilaianbpi1'][$k]['ujian_tertulis'];
    if ($nsmt6 < 60) {
        $nsmt6 = 1;
    } elseif ($nsmt6 >= 60 && $nsmt6 <= 69) {
        $nsmt3 = 2;
    } elseif ($nsmt6 >= 70 && $nsmt6 <= 84) {
        $nsmt6 = 3;
    } else {
        $nsmt6 = 4;
    }
    array_push($Rc6, $nsmt6 / $Rmax6 * 3);
}
//END RC6
//RC7
$Rmax7 = 0;
for ($i = 0; $i < $total_data; $i++) {
    // loop data nilai
    $smt7 = $data4['penilaianbpi1'][$i]['absensi'];
    //end loop
    if ($i < $total_data) {
        if ($smt7 >= $Rmax7) {
            $Rmax7 = $smt7;
        } elseif ($smt7 < $Rmax7) {
            $Rmax7 = $Rmax7;
        }
    }
}
//validasi nilai
if ($Rmax7 = 0) {
    $Rmax7 = 4;
} elseif ($Rmax7 >= 1 && $Rmax7 <= 2) {
    $Rmax1 = 3;
} elseif ($Rmax7 >= 3 && $Rmax7 <= 4) {
    $Rmax7 = 2;
} elseif ($Rmax7 >= 5) {
    $Rmax7 = 1;
}
//end validasi
$Rc7 = array();
for ($j = 0; $j < $total_data; $j++) {
    $nsmt7 = $data4['penilaianbpi1'][$j]['absensi'];
    if ($Rmax7 <= 1) {
        $Rmax7 = 4;
    } elseif ($Rmax7 >= 1 && $Rmax7 <= 2) {
        $Rmax1 = 3;
    } elseif ($Rmax7 >= 3 && $Rmax7 <= 4) {
        $Rmax7 = 2;
    } elseif ($Rmax7 >= 5) {
        $Rmax7 = 1;
    }
    array_push($Rc7, $nsmt7 / $Rmax7 * 2);
}
//END RC7
$arr_nilai_akhir = array();
for ($i = 0; $i < $total_data; $i++) {
    $nilai_akhir = $Rc1[$i] + $Rc2[$i] + $Rc3[$i] + $Rc4[$i] + $Rc5[$i] + $Rc6[$i] + $Rc7[$i];
    if ($nilai_akhir < 7) {

        $nilai_akhir = 'Ditolak';
    } elseif ($nilai_akhir > 7) {

        $nilai_akhir = 'Diterima';
    }
    // $data4['penilaianbpi1'] = $this->db->query("INSERT INTO penilaianbpi1 (pernyataan) VALUES ('$nilai_akhir')");
    array_push($arr_nilai_akhir, $nilai_akhir);

    //var_dump($nilai_akhir);
    // echo "<br><br>";

}

// var_dump($Rc1[0]);
// echo "<br><br>";
// var_dump($Rc2[0]);
// echo "<br><br>";
// var_dump($Rc3[0]);
// echo "<br><br>";
// var_dump($Rc4[0]);
// echo "<br><br>";
// var_dump($Rc5[0]);
// echo "<br><br>";
// var_dump($Rc6[0]);
// echo "<br><br>";
// var_dump($Rc7[0]);
// echo "<br><br>";

// $nilai_akhir = $Rc1[0] + $Rc2[0] + $Rc3[0] + $Rc4[0] + $Rc5[0] + $Rc6[0] + $Rc7[0];
// var_dump($nilai_akhir);
// die;
?>
<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center"></a>
    <div>
        <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>
    </div>
    <div class="card shadow mb-4">
        <?= $this->session->flashdata('message'); ?>
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Penilaian siswa BPI 1</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <div class="row">
                        <form class="user" method="POST" action="<?= base_url('admin/proses_nilaibpi1') ?>">
                            <div class="col-lg-16">

                                <table class="table table-hover">
                                    <thead>
                                        <tr>

                                            <th scope="col">nama</th>
                                            <th scope="col">Nilai Semester1</th>
                                            <th scope="col">Nilai Semester2</th>
                                            <th scope="col">Nilai Semester3</th>
                                            <th scope="col">Nilai Semester4</th>
                                            <th scope="col">Nilai Semester5</th>
                                            <th scope="col">Ujia Tertulis</th>
                                            <th scope="col">Absensi</th>


                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>



                                            <td>
                                                <div class="form-group">
                                                    <input type="text" class="form-control form-control-user" id="nama" name="nama" placeholder="nama" value="<?= set_value('nama') ?>">
                                                </div>
                                            </td>
                                            <td>
                                                <div class="form-group">
                                                    <input type="text" class="form-control form-control-user" id="semester1" name="semester1" placeholder="nilai" value="<?= set_value('semester1') ?>">
                                                </div>
                                            </td>
                                            <td>
                                                <div class="form-group">
                                                    <input type="text" class="form-control form-control-user" id="semester2" name="semester2" placeholder="nilai" value="<?= set_value('semester2') ?>">
                                                </div>
                                            </td>
                                            <td>
                                                <div class="form-group">
                                                    <input type="text" class="form-control form-control-user" id="semester3" name="semester3" placeholder="nilai" value="<?= set_value('semester3') ?>">
                                                </div>
                                            </td>
                                            <td>
                                                <div class="form-group">
                                                    <input type="text" class="form-control form-control-user" id="semester4" name="semester4" placeholder="nilai" value="<?= set_value('semester4') ?>">
                                                </div>
                                            </td>
                                            <td>
                                                <div class="form-group">
                                                    <input type="text" class="form-control form-control-user" id="semester5" name="semester5" placeholder="nilai" value="<?= set_value('semester5') ?>">
                                                </div>
                                            </td>
                                            <td>
                                                <div class="form-group">
                                                    <input type="text" class="form-control form-control-user" id="ujian_tertulis" name="ujian_tertulis" placeholder="nilai" value="<?= set_value('ujian_tertulis') ?>">
                                                </div>
                                            </td>
                                            <td>
                                                <div class="form-group">
                                                    <input type="text" class="form-control form-control-user" id="absensi" name="absensi" placeholder="nilai" value="<?= set_value('absensi') ?>">
                                                </div>
                                            </td>
                                            <td>
                                                <button type="Submit" class="btn btn-primary">Masukan</button>
                                            </td>
                                        </tr>


                                </table>
                        </form>
                    </div>
            </div>
        </div>
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Hasil siswa BPI 1</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <div class="row">
                            <div class="col-lg-16">

                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th scope="col">NO</th>
                                            <th scope="col">nama</th>
                                            <th scope="col">Nilai Semester1</th>
                                            <th scope="col">Nilai Semester2</th>
                                            <th scope="col">Nilai Semester3</th>
                                            <th scope="col">Nilai Semester4</th>
                                            <th scope="col">Nilai Semester5</th>
                                            <th scope="col">Ujia Tertulis</th>
                                            <th scope="col">Absensi</th>
                                            <th scope="col">Nilai Akhir</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $i = 1; ?>
                                        <?php foreach ($penilaianbpi1 as $nilai) : ?>
                                            <tr>
                                                <th scope="row"><?= $i; ?></th>
                                                <td><?= $nilai['nama'];  ?></td>
                                                <td><?= $nilai['semester1'];  ?></td>
                                                <td><?= $nilai['semester2'];  ?></td>
                                                <td><?= $nilai['semester3'];  ?></td>
                                                <td><?= $nilai['semester4'];  ?></td>
                                                <td><?= $nilai['semester5'];  ?></td>
                                                <td><?= $nilai['ujian_tertulis'];  ?></td>
                                                <td><?= $nilai['absensi'];  ?></td>
                                                <td><?= $arr_nilai_akhir[$i - 1];  ?></td>
                                            </tr>
                                            <?php $i++ ?>
                                        <?php endforeach; ?>
                                </table>
                                <a href="<?= base_url('admin/exportpenilaianbpi1') ?>" class="btn btn-primary">export ke excel</a>
                            </div>
                        </div>
                </div>
            </div>

            <!-- /.container-fluid -->