 <!-- Begin Page Content -->
 <div class="container-fluid">

     <!-- Page Heading -->
     <a class="sidebar-brand d-flex align-items-center justify-content-center"></a>
     <div>
         <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>
     </div>
     <div class="card shadow mb-4">
         <div class="card-header py-3">
             <h6 class="m-0 font-weight-bold text-primary">Data Siswa</h6>
         </div>
         <div class="card-body">
             <div class="table-responsive">
                 <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                     <div class="row">
                         <div class="col-lg-16">
                             <table class="table table-hover">
                                 <tr>
                                     <th scope="col">NO</th>
                                     <th scope="col">NIS</th>
                                     <th scope="col">Nama</th>
                                     <th scope="col">Sekolah </th>
                                     <th scope="col">Alamat</th>
                                     <th scope="col">Nama Orang tua</th>
                                     <th scope="col">Nomor HP</th>
                                     <th scope="col">Tempat Lahir</th>
                                     <th scope="col">Tanggal Lahir</th>
                                     <th scope="col">Asal Sekolah</th>
                                 </tr>
                                 </thead>
                                 <tbody>
                                     <?php $i = 1; ?>
                                     <?php foreach ($regis_siswa as $regis) : ?>
                                         <tr>
                                             <th scope="row"><?= $i; ?></th>
                                             <td><?= $regis['nis'];  ?></td>
                                             <td><?= $regis['nama'];  ?></td>
                                             <td><?= $regis['sekolah'];  ?></td>
                                             <td><?= $regis['alamat'];  ?></td>
                                             <td><?= $regis['nama_ortu'];  ?></td>
                                             <td><?= $regis['no_hp'];  ?></td>
                                             <td><?= $regis['tempat_lahir'];  ?></td>
                                             <td><?= $regis['tgl_lahir'];  ?></td>
                                             <td><?= $regis['asal_sekolah'];  ?></td>
                                         </tr>
                                         <?php $i++ ?>
                                     <?php endforeach; ?>
                             </table>
                             <a href="<?= base_url('admin/datasdexport') ?>" class="btn btn-primary">Export Ke Excel</a>
                         </div>
                     </div>

             </div>
         </div>

         <!-- /.container-fluid -->