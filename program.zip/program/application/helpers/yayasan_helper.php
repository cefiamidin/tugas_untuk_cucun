<?php


function is_logged_in()
{
    $ci = get_instance();
    if (!$ci->session->userdata('username')) {
        redirect('auth');
    }
}
function is_logged_user()
{
    $ci = get_instance();
    if (!$ci->session->userdata('regis_siswa', ['username'])) {
        redirect('admin');
    }
}
function is_logged_admin()
{
    $ci = get_instance();
    if ($ci->session->userdata('admin', ['username', 'password'])) {
        redirect('admin');
    }
}
