-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 08, 2020 at 03:57 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ppdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `nama` varchar(128) NOT NULL,
  `username` varchar(128) NOT NULL,
  `password` varchar(256) NOT NULL,
  `verifikasi` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `nama`, `username`, `password`, `verifikasi`) VALUES
(21, 'Admin SMA BPI1', 'adminbpi1', '$2y$10$MbVEpWeAHyU0b0KtjqqweeT8YhyvqH2UAo3zgpRKJAQOxTF0iUD4C', 1),
(22, 'Admin SMA BPI2', 'adminbpi2', '$2y$10$QMcZOIQHCh5IFxOXw3PtJO42lmGdAciuhcVhwDH34QhAsy9gtMWae', 1),
(23, 'Admin SMK BPI', 'adminsmk', '$2y$10$u5WMiTv.bBIPojX3lUL60uBvk.tcBFV8bEjJwSiAwakrZw46lIYja', 1),
(24, 'Admin SMP BPI', 'adminsmp', '$2y$10$u/zWZsjvwjYMPJkPfT6lAukzia0b8xjczmPvHEyyqZRD3HWiMqBF.', 1),
(25, 'Admin SD BPI', 'adminsd', '$2y$10$wDoxEWLWoY/HKAvYsZkROeGWMxm6Zh.5n2yVEGvxmJ4VrhIGIJuXG', 1),
(26, 'Admin TK-PG', 'admintk', '$2y$10$WMrU75tSJUq6aiIcDFUun./W0KPJ7smpE5m8IfQnWpYyyB3Y.JGlK', 1),
(27, 'Yayasan BPI Bandung', 'yayasanbpi', '$2y$10$gktd.m02hEfqlkqgXQjdm.vk7o.0PDURipvUtrCqykH3lbnph7iUS', 1);

-- --------------------------------------------------------

--
-- Table structure for table `pengumuman`
--

CREATE TABLE `pengumuman` (
  `id` int(11) NOT NULL,
  `untuk` varchar(255) NOT NULL,
  `buat_pengumuman` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pengumuman`
--

INSERT INTO `pengumuman` (`id`, `untuk`, `buat_pengumuman`) VALUES
(5, 'Calon SMA BPI 1', 'untuk calon siswa SMA BPI 1 diharapkan pada tanggal 10 maret 2020 membawa berkas. terima kasih'),
(17, 'Calon SMK BPI', 'diharapkan besok membawa berkas terkait'),
(18, 'Calon SMA BPI 1', 'ditunggu pengumpulan berkasnya');

-- --------------------------------------------------------

--
-- Table structure for table `penilaian`
--

CREATE TABLE `penilaian` (
  `id_nilai` int(11) NOT NULL,
  `nama` varchar(125) NOT NULL,
  `semester1` int(10) NOT NULL,
  `semester2` int(10) NOT NULL,
  `semester3` int(10) NOT NULL,
  `semester4` int(10) NOT NULL,
  `semester5` int(10) NOT NULL,
  `ujian_tertulis` int(10) NOT NULL,
  `absensi` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penilaian`
--

INSERT INTO `penilaian` (`id_nilai`, `nama`, `semester1`, `semester2`, `semester3`, `semester4`, `semester5`, `ujian_tertulis`, `absensi`) VALUES
(120, 'Anis Bawean', 90, 90, 90, 80, 80, 80, 4),
(122, 'udin', 60, 60, 60, 60, 60, 60, 2),
(123, 'Nur Rohman', 90, 90, 80, 80, 80, 80, 1),
(128, 'Farrid ', 50, 50, 50, 50, 50, 50, 1),
(130, 'ujang', 90, 90, 90, 90, 90, 90, 1),
(131, 'ayu andara', 77, 80, 80, 80, 80, 90, 4),
(132, 'Desta', 60, 50, 60, 60, 50, 50, 1),
(133, 'Cefi Amidin M', 65, 85, 80, 70, 70, 75, 3),
(134, 'ayu andara', 50, 50, 50, 50, 45, 60, 1),
(135, 'Farrid ', 40, 40, 40, 40, 40, 40, 1);

-- --------------------------------------------------------

--
-- Table structure for table `penilaianbpi1`
--

CREATE TABLE `penilaianbpi1` (
  `id_nilai` int(11) NOT NULL,
  `nama` varchar(128) NOT NULL,
  `semester1` int(10) NOT NULL,
  `semester2` int(10) NOT NULL,
  `semester3` int(10) NOT NULL,
  `semester4` int(10) NOT NULL,
  `semester5` int(10) NOT NULL,
  `ujian_tertulis` int(10) NOT NULL,
  `absensi` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penilaianbpi1`
--

INSERT INTO `penilaianbpi1` (`id_nilai`, `nama`, `semester1`, `semester2`, `semester3`, `semester4`, `semester5`, `ujian_tertulis`, `absensi`) VALUES
(113, 'Cefi Amidin Muhrifa', 80, 70, 60, 70, 70, 75, 4),
(114, 'Shafa Madani', 55, 50, 60, 40, 40, 40, 5),
(115, 'ujang', 90, 90, 90, 90, 90, 90, 1),
(116, 'deden', 90, 90, 90, 90, 90, 90, 90);

-- --------------------------------------------------------

--
-- Table structure for table `penilaianbpi2`
--

CREATE TABLE `penilaianbpi2` (
  `id_nilai` int(11) NOT NULL,
  `nama` varchar(128) NOT NULL,
  `semester1` int(10) NOT NULL,
  `semester2` int(10) NOT NULL,
  `semester3` int(10) NOT NULL,
  `semester4` int(10) NOT NULL,
  `semester5` int(10) NOT NULL,
  `ujian_tertulis` int(10) NOT NULL,
  `absensi` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `penilaiansmk`
--

CREATE TABLE `penilaiansmk` (
  `id_nilai` int(11) NOT NULL,
  `nama` varchar(128) NOT NULL,
  `semester1` int(10) NOT NULL,
  `semester2` int(10) NOT NULL,
  `semester3` int(10) NOT NULL,
  `semester4` int(10) NOT NULL,
  `semester5` int(10) NOT NULL,
  `ujian_tertulis` int(10) NOT NULL,
  `absensi` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `regis_siswa`
--

CREATE TABLE `regis_siswa` (
  `id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `nis` varchar(50) NOT NULL,
  `sekolah` varchar(128) NOT NULL,
  `nama` varchar(128) NOT NULL,
  `jenis_kelamin` varchar(125) NOT NULL,
  `nama_ortu` varchar(128) NOT NULL,
  `no_hp` bigint(15) NOT NULL,
  `asal_sekolah` varchar(128) NOT NULL,
  `tempat_lahir` varchar(128) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `alamat` text NOT NULL,
  `email` varchar(125) NOT NULL,
  `username` varchar(125) NOT NULL,
  `password` varchar(125) NOT NULL,
  `verifikasi` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `regis_siswa`
--

INSERT INTO `regis_siswa` (`id`, `role_id`, `nis`, `sekolah`, `nama`, `jenis_kelamin`, `nama_ortu`, `no_hp`, `asal_sekolah`, `tempat_lahir`, `tgl_lahir`, `alamat`, `email`, `username`, `password`, `verifikasi`) VALUES
(0, 2, '1718361060063', 'SMK BPI', 'ZAHRANYSSA FAHILAH', 'P', 'Fadilah Nurcahya', 81310128666, 'SMP 35 Bandung', 'Bandung', '2007-12-18', 'jln, cipadung', 'fahilah@gmail.com', 'fahilah123', 'fahilah123', '0'),
(61, 2, '-', 'Tk-PG BPI', 'Adora Zoya Ivan', 'L', 'Ivan Gunawan', 81321329998, '-', 'Bandung', '2016-03-15', 'jln, sadakeling', 'ivangunawan@gmail.com', 'ivangunawan', '$2y$10$pc/7t4cKCiY3iyzeiwvy/.uxtbh5oOcxUjK7ebHT.sbC4Z6WJjI8i', '1'),
(62, 2, '-', 'Tk-PG BPI', 'Alena Naura Krasi', 'L', 'Naura Indah', 81321188528, '-', 'Bandung', '2016-01-14', 'jln, sadangserang', 'nauraindah@gmail.com', 'nauraindah', '$2y$10$25kyaGOk3pOSnd19zA8DNulEblhV7SHHk5bTBaoF5NgO1YwWRT0xe', '1'),
(63, 2, '-', 'Tk-PG BPI', 'Alvaro Zufarino', 'L', 'cecep sudrajat', 81321188564, '-', 'Bandung', '2016-05-21', 'jln, sadangserang kp karang asih', 'cecepsudrajat@gmail.com', 'cecep123', '$2y$10$LEt5w4t6JiIxzbTkUGKkX.u2RIpJoel8y/J7B3vWjh7/GOfnGaJiO', '1'),
(64, 2, '-', 'Tk-PG BPI', 'Alyssa Dyandra', 'P', 'Indah Kumalasari', 81321188500, '-', 'Bandung', '2016-06-12', 'jln, gagak dalam', 'indahkumalasari@gmail.com', 'indah123', '$2y$10$ZdRWFOS71e68YFdXIicNo.OJqGrRhkNNQHpj2E5dXbo9H.Gptq89S', '1'),
(65, 2, '-', 'Tk-PG BPI', 'Jusuf Keanu', 'L', 'Keanu lubis', 81323328500, '-', 'Bandung', '2016-10-04', 'jln, puyuh dalan rt 06', 'keanulubis@gmail.com', 'keanu123', '$2y$10$XmRlW9AlR.LrcyquxAdjMe/0Yalv9/AbXjeUCXoRxW.9ws.0NZLc.', '0'),
(66, 2, '-', 'Tk-PG BPI', 'Keisya Aqila', 'L', 'intan permana', 81310128500, '-', 'Bandung', '2016-04-28', 'jln, gelatik dalan rt 06', 'intanpermana@gmail.com', 'intan123', '$2y$10$ffXk8.qnOnQW1xaOqpKI9.aagdfbQNj8nnKKaVfyRKfJQU4ZImF7K', '1'),
(67, 2, '1718361060001', 'SD BPI', 'ARFI AHMAD WIBAWA', 'L', 'Ahmad Albar', 81310128120, 'TK Bpi', 'Bandung', '2016-06-28', 'jln, gelatik dalan rt 100', 'ahmadalbar@gmail.com', 'ahmad123', '$2y$10$MDLx/gL3lKYRAdcU.JFiges7wAciOLSNzP/EGqFZ9JbOVMqbUlh.S', '1'),
(68, 2, '1718361060002', 'SD BPI', 'BAGUS DWI RAHADYANSYAH', 'L', 'Dewi intan', 81310128130, 'TK As-Salam', 'Bandung', '2010-06-28', 'jln, dederuk indah', 'dewiintan@gmail.com', 'bagus123', '$2y$10$tJbMrcVcNietl4BoYNdPWONWetzTYtYH7eJ8Mw23usUmJjPw/u4fi', '1'),
(69, 2, '1718361060003', 'SD BPI', 'BALADIVA MAHESA SAKA KIRANA', 'P', 'mahesa indah', 81310128900, '-', 'Bandung', '2010-01-28', 'jln, dederuk indah kulon', 'mahesaintan@gmail.com', 'kirana123', '$2y$10$/pZvNJuyPUevP/5L7NyzeObXTqVm72hlkEHi0NUi.AAqBXRfUoBOm', '1'),
(70, 2, '1718361060004', 'SD BPI', 'CLARISSA FAZA AUDRINA', 'P', 'ayu tingting', 81310128800, '-', 'Bandung', '2010-10-05', 'jln, tpu nagrog ujung berung', 'tingting@gmail.com', 'tingting123', '$2y$10$ppPiXDCQUM3JQXF1WQxsxuYrTYWD9M/IoRVAFDLsDBmMyTL1x5fZW', '1'),
(71, 2, '1718361060059', 'SMP BPI', 'NUR ROHMAN SULAIMAN\r\n', 'P', 'Dikri fauzan', 81310128303, 'SD Tilil 2', 'Bandung', '2013-03-19', 'jln, singkayo kulon', 'sulaiman@gmail.com', 'sulaiman123', 'sulaiman123', '1'),
(72, 2, '1718361060061', 'SMA BPI 1', 'SHAFA MADANI\r\n', 'P', 'Madani intan', 81310128123, 'SMP 16 Bandung', 'Bandung', '2007-05-19', 'jln, sindanglaya tengah', 'shafamadani@gmail.com', 'shafa123', 'shafa123', '1'),
(73, 2, '1718361060062', 'SMA BPI 2', 'WISNU ADITYA NUSABEKTI\r\n', 'L', 'wisnu aditya', 81310128700, 'SMP Pasundan 8', 'Bandung', '2010-05-19', 'jln, dederuk indah kulon', 'wisnuaditya@gmail.com', 'wisnu123', 'wisnu123', '1'),
(85, 2, '10116220', 'SMA BPI 1', 'Cefi Amidin Muhrifa', 'L', 'cahyo hermawan', 81321188564, 'SMP Negri 16 Bandung', 'Garut', '1998-05-19', 'jalan gagak', 'cefiamidin@gmail.com', 'cefiamidin', '$2y$10$qo21wfwsZthwOD1TNCF42OeitOYJVyQhAKnonROMQJdGlJDWOgkIS', '1');

-- --------------------------------------------------------

--
-- Table structure for table `user_token`
--

CREATE TABLE `user_token` (
  `id` int(11) NOT NULL,
  `email` varchar(128) NOT NULL,
  `token` varchar(128) NOT NULL,
  `date_created` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_token`
--

INSERT INTO `user_token` (`id`, `email`, `token`, `date_created`) VALUES
(37, 'cefiamidin@gmail.com', '7Jy6FZGA0n2yJTQamJD+ZMFMW2ofZtIGwkZy94Y8XqI=', 1595732872);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pengumuman`
--
ALTER TABLE `pengumuman`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `penilaian`
--
ALTER TABLE `penilaian`
  ADD PRIMARY KEY (`id_nilai`);

--
-- Indexes for table `penilaianbpi1`
--
ALTER TABLE `penilaianbpi1`
  ADD PRIMARY KEY (`id_nilai`);

--
-- Indexes for table `penilaianbpi2`
--
ALTER TABLE `penilaianbpi2`
  ADD PRIMARY KEY (`id_nilai`);

--
-- Indexes for table `penilaiansmk`
--
ALTER TABLE `penilaiansmk`
  ADD PRIMARY KEY (`id_nilai`);

--
-- Indexes for table `regis_siswa`
--
ALTER TABLE `regis_siswa`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_token`
--
ALTER TABLE `user_token`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `pengumuman`
--
ALTER TABLE `pengumuman`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `penilaian`
--
ALTER TABLE `penilaian`
  MODIFY `id_nilai` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=136;

--
-- AUTO_INCREMENT for table `penilaianbpi1`
--
ALTER TABLE `penilaianbpi1`
  MODIFY `id_nilai` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117;

--
-- AUTO_INCREMENT for table `penilaianbpi2`
--
ALTER TABLE `penilaianbpi2`
  MODIFY `id_nilai` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `penilaiansmk`
--
ALTER TABLE `penilaiansmk`
  MODIFY `id_nilai` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `regis_siswa`
--
ALTER TABLE `regis_siswa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;

--
-- AUTO_INCREMENT for table `user_token`
--
ALTER TABLE `user_token`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
